"use client"

import type React from "react"

import { useState } from "react"
import { TerminalSandbox } from "@/components/terminal-sandbox"
import { MainNav } from "@/components/main-nav"
import { StatsDrawer } from "@/components/stats-drawer"
import { Terminal, Code, Key } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function Home() {
  const [activeView, setActiveView] = useState("home")
  const [isTerminalOpen, setIsTerminalOpen] = useState(false)
  const [isStatsOpen, setIsStatsOpen] = useState(false)
  const [apiKey, setApiKey] = useState("")
  const [isApiKeySet, setIsApiKeySet] = useState(false)
  const [currentOS, setCurrentOS] = useState("kali") // Default OS

  const handleViewChange = (view: string) => {
    if (view === "terminal") {
      setIsTerminalOpen(true)
      setActiveView("terminal")
    } else if (view === "stats") {
      setIsStatsOpen(true)
    } else {
      setActiveView(view)
    }
  }

  const handleApiKeySubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (apiKey.trim()) {
      setIsApiKeySet(true)
      setIsTerminalOpen(true)
      setActiveView("terminal")
    }
  }

  const handleSwitchOS = (os: string) => {
    setCurrentOS(os)

    // If terminal is not open, open it
    if (!isTerminalOpen) {
      setIsTerminalOpen(true)
      setActiveView("terminal")
    }

    // Dispatch an event to notify the terminal
    const event = new CustomEvent("switch-os", {
      detail: { os },
    })
    document.dispatchEvent(event)
  }

  return (
    <main className="min-h-screen bg-[#0f1117] text-[#f7fafc] flex flex-col">
      <MainNav
        activeView={activeView}
        onViewChange={handleViewChange}
        onToggleStats={() => setIsStatsOpen(!isStatsOpen)}
        onSwitchOS={handleSwitchOS}
      />

      <div className="flex-1 flex flex-col items-center justify-center p-4">
        {activeView !== "terminal" && (
          <div className="w-full max-w-5xl mx-auto mb-8 text-center">
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-[#3b82f6] to-[#8b5cf6] bg-clip-text text-transparent">
              CloakAI Terminal
            </h1>
            <p className="text-[#a0aec0] max-w-md mx-auto mb-8">
              Advanced cybersecurity toolkit with integrated AI assistance
            </p>

            {!isApiKeySet ? (
              <div className="max-w-md mx-auto bg-[#1a202c] p-6 rounded-xl shadow-xl border border-[#2d3748]">
                <form onSubmit={handleApiKeySubmit} className="space-y-4">
                  <div className="flex items-center justify-center mb-4">
                    <Key size={24} className="text-[#3b82f6]" />
                  </div>
                  <Label htmlFor="api-key" className="text-[#f7fafc] text-left block">
                    Enter API Key
                  </Label>
                  <Input
                    id="api-key"
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="Enter your API key"
                    className="bg-[#0f1117] border-[#2d3748] text-[#f7fafc]"
                    required
                  />
                  <Button
                    type="submit"
                    className="w-full bg-[#3b82f6] hover:bg-[#2563eb] text-white py-2 rounded-md transition-colors"
                  >
                    Continue
                  </Button>
                  <p className="text-xs text-[#a0aec0] mt-2">
                    Your API key is required to use the terminal and AI features.
                  </p>
                </form>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                <Button
                  size="lg"
                  onClick={() => {
                    setIsTerminalOpen(true)
                    setActiveView("terminal")
                    handleSwitchOS("kali")
                  }}
                  className="bg-[#1a202c] hover:bg-[#2d3748] text-[#f7fafc] flex items-center gap-2 p-6 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl h-auto border border-[#2d3748]"
                >
                  <Terminal className="h-6 w-6 text-[#f56565]" />
                  <div className="flex flex-col items-start">
                    <span className="text-xl font-bold text-[#f56565]">Kali Linux</span>
                    <span className="text-sm text-[#a0aec0]">Advanced penetration testing tools</span>
                  </div>
                </Button>

                <Button
                  size="lg"
                  onClick={() => {
                    setIsTerminalOpen(true)
                    setActiveView("terminal")
                    handleSwitchOS("alpine")
                  }}
                  className="bg-[#1a202c] hover:bg-[#2d3748] text-[#f7fafc] flex items-center gap-2 p-6 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl h-auto border border-[#2d3748]"
                >
                  <Code className="h-6 w-6 text-[#3b82f6]" />
                  <div className="flex flex-col items-start">
                    <span className="text-xl font-bold text-[#3b82f6]">Alpine Linux</span>
                    <span className="text-sm text-[#a0aec0]">Lightweight and secure environment</span>
                  </div>
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Terminal container - centered and at the bottom */}
        <div className="w-full max-w-6xl mx-auto mt-auto">
          {activeView === "terminal" && isTerminalOpen && (
            <TerminalSandbox
              isOpen={isTerminalOpen}
              onClose={() => {
                setIsTerminalOpen(false)
                setActiveView("home")
              }}
              isMainView={true}
              apiKey={apiKey}
              initialOS={currentOS}
            />
          )}
        </div>
      </div>

      {/* Stats drawer */}
      <StatsDrawer isOpen={isStatsOpen} onClose={() => setIsStatsOpen(false)} />
    </main>
  )
}

