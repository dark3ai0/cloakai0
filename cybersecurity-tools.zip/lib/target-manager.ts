export interface Target {
  ip: string
  domain: string
  username: string
  email: string
  phoneNumber: string
}

export class TargetManager {
  private target: Target = {
    ip: "",
    domain: "",
    username: "",
    email: "",
    phoneNumber: "",
  }
  private listeners: ((target: Target) => void)[] = []

  constructor() {
    // Initialize with empty values
  }

  public getTarget(): Target {
    return { ...this.target }
  }

  public setTarget(newTarget: Partial<Target>): void {
    this.target = {
      ...this.target,
      ...newTarget,
    }
    this.notifyListeners()
  }

  public updateField(field: keyof Target, value: string): void {
    this.target[field] = value
    this.notifyListeners()
  }

  public addListener(listener: (target: Target) => void): void {
    this.listeners.push(listener)
  }

  public removeListener(listener: (target: Target) => void): void {
    this.listeners = this.listeners.filter((l) => l !== listener)
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => listener(this.getTarget()))
  }

  public replaceTargetPlaceholders(command: string): string {
    let result = command

    // Replace all common placeholder patterns
    if (this.target.ip) {
      result = result.replace(/<target_ip>/g, this.target.ip)
      result = result.replace(/<ip>/g, this.target.ip)
      result = result.replace(/\[ip\]/g, this.target.ip)
    }

    if (this.target.domain) {
      result = result.replace(/<target_domain>/g, this.target.domain)
      result = result.replace(/<domain>/g, this.target.domain)
      result = result.replace(/\[domain\]/g, this.target.domain)
      result = result.replace(/<target>/g, this.target.domain)
    }

    if (this.target.username) {
      result = result.replace(/<username>/g, this.target.username)
      result = result.replace(/\[username\]/g, this.target.username)
    }

    if (this.target.email) {
      result = result.replace(/<email>/g, this.target.email)
      result = result.replace(/\[email\]/g, this.target.email)
    }

    if (this.target.phoneNumber) {
      result = result.replace(/<phone_number>/g, this.target.phoneNumber)
      result = result.replace(/<phone>/g, this.target.phoneNumber)
      result = result.replace(/\[phone\]/g, this.target.phoneNumber)
    }

    return result
  }
}

