export interface Tool {
  id: string
  name: string
  description: string
  command: string
  category: string
}

export interface Category {
  id: string
  name: string
}

export const categories: Category[] = [
  {
    id: "web-scraping",
    name: "Web Scraping & Data Analysis",
  },
  {
    id: "cybersecurity",
    name: "Cybersecurity & Threat Intelligence",
  },
  {
    id: "apis",
    name: "APIs & Data Sources",
  },
  {
    id: "miscellaneous",
    name: "Miscellaneous",
  },
  // New categories
  {
    id: "forensics",
    name: "Digital Forensics",
  },
  {
    id: "wireless",
    name: "Wireless Security",
  },
  {
    id: "password-cracking",
    name: "Password Cracking",
  },
  {
    id: "exploitation",
    name: "Exploitation",
  },
  {
    id: "post-exploitation",
    name: "Post-Exploitation",
  },
]

export const tools: Tool[] = [
  // Web Scraping & Data Analysis
  {
    id: "web-analytics-extractor",
    name: "Web Analytics Extractor",
    description: "Extract web analytics IDs from scraped webpages and DNS TLD records.",
    command: "apk add web-analytics-extractor && web-analytics-extractor -h <target_url>",
    category: "web-scraping",
  },
  {
    id: "web-framework-identifier",
    name: "Web Framework Identifier",
    description: "Identify the usage of popular web frameworks like jQuery, YUI, and others.",
    command: "apk add web-framework-identifier && web-framework-identifier -h <target_url>",
    category: "web-scraping",
  },
  {
    id: "web-server-identifier",
    name: "Web Server Identifier",
    description: "Obtain web server banners to identify versions of web servers being used.",
    command: "apk add web-server-identifier && web-server-identifier -h <target_url>",
    category: "web-scraping",
  },
  {
    id: "web-spider",
    name: "Web Spider",
    description: "Scrape webpages to extract content for searching.",
    command: "apk add web-spider && web-spider -h <target_url>",
    category: "web-scraping",
  },
  {
    id: "wappalyzer",
    name: "Wappalyzer",
    description: "Identify technologies on websites.",
    command: "apk add wappalyzer && wappalyzer -h <target_url>",
    category: "web-scraping",
  },
  {
    id: "whatweb",
    name: "WhatWeb",
    description: "Identify software used on a specified website.",
    command: "apk add whatweb && whatweb -h <target_url>",
    category: "web-scraping",
  },

  // Cybersecurity & Threat Intelligence
  {
    id: "threat-jammer",
    name: "Threat Jammer",
    description: "Check if an IP address is malicious according to ThreatJammer.com.",
    command: "apk add threatjammer && threatjammer -h <target_ip>",
    category: "cybersecurity",
  },
  {
    id: "threatcrowd",
    name: "ThreatCrowd",
    description: "Obtain information from ThreatCrowd about identified IP addresses, domains, and email addresses.",
    command: "apk add threatcrowd && threatcrowd -h <target_ip>",
    category: "cybersecurity",
  },
  {
    id: "threatfox",
    name: "ThreatFox",
    description: "Check if an IP address is malicious according to ThreatFox.",
    command: "apk add threatfox && threatfox -h <target_ip>",
    category: "cybersecurity",
  },
  {
    id: "threatminer",
    name: "ThreatMiner",
    description: "Obtain information from ThreatMiner's database for passive DNS and threat intelligence.",
    command: "apk add threatminer && threatminer -h <target_ip>",
    category: "cybersecurity",
  },
  {
    id: "tld-searcher",
    name: "TLD Searcher",
    description: "Search all Internet TLDs for domains with the same name as the target.",
    command: "apk add tld-searcher && tld-searcher -h <target_domain>",
    category: "cybersecurity",
  },
  {
    id: "ssl-certificate-analyzer",
    name: "SSL Certificate Analyzer",
    description: "Gather information about SSL certificates used by the target's HTTPS sites.",
    command: "apk add ssl-certificate-analyzer && ssl-certificate-analyzer -h <target_url>",
    category: "cybersecurity",
  },

  // APIs & Data Sources
  {
    id: "vxvault",
    name: "VXVault",
    description: "Check if a domain or IP address is malicious according to VXVault.net.",
    command: "apk add vxvault && vxvault -h <target_domain>",
    category: "apis",
  },
  {
    id: "whoisology",
    name: "Whoisology",
    description: "Perform a reverse Whois lookup on a domain name.",
    command: "apk add whoisology && whoisology -h <target_domain>",
    category: "apis",
  },
  {
    id: "wigle",
    name: "WiGLE",
    description: "Query WiGLE to identify nearby WiFi access points.",
    command: "apk add wigel && wigel -h <target_ip>",
    category: "apis",
  },
  {
    id: "wikipedia-edits",
    name: "Wikipedia Edits",
    description: "Identify edits to Wikipedia articles made from a given IP address or username.",
    command: "apk add wikipedia-edits && wikipedia-edits -h <target_ip>",
    category: "apis",
  },
  {
    id: "xforce-exchange",
    name: "XForce Exchange",
    description: "Obtain IP reputation and passive DNS information from IBM X-Force Exchange.",
    command: "apk add xforce-exchange && xforce-exchange -h <target_ip>",
    category: "apis",
  },
  {
    id: "yandex-dns",
    name: "Yandex DNS",
    description: "Check if a host would be blocked by Yandex DNS.",
    command: "apk add yandex-dns && yandex-dns -h <target_domain>",
    category: "apis",
  },

  // Miscellaneous
  {
    id: "adblock-check",
    name: "AdBlock Check",
    description: "Check if a domain is on the AdBlock list.",
    command: "apk add adblock-check && adblock-check -h <target_domain>",
    category: "miscellaneous",
  },
  {
    id: "adguard-dns",
    name: "AdGuard DNS",
    description: "Check if a host would be blocked by AdGuard DNS.",
    command: "apk add adguard-dns && adguard-dns -h <target_domain>",
    category: "miscellaneous",
  },
  {
    id: "ahmia",
    name: "Ahmia",
    description: "Search for Tor hidden services (onion sites) using Ahmia.fi.",
    command: "apk add ahmia && ahmia -h <search_term>",
    category: "miscellaneous",
  },
  {
    id: "s3-bucket-finder",
    name: "Amazon S3 Bucket Finder",
    description: "Find open Amazon S3 buckets and their contents.",
    command: "apk add s3-bucket-finder && s3-bucket-finder -h <target_domain>",
    category: "miscellaneous",
  },
  {
    id: "archive-org",
    name: "Archive.org",
    description: "Search the Internet Archive for historical snapshots of websites.",
    command: "apk add archive-org && archive-org -h <target_url>",
    category: "miscellaneous",
  },
  // Add new tools
  // Forensics tools
  {
    id: "volatility",
    name: "Volatility",
    description: "Advanced memory forensics framework for analyzing RAM dumps.",
    command: "volatility -f memory.dmp imageinfo",
    category: "forensics",
  },
  {
    id: "autopsy",
    name: "Autopsy",
    description: "Digital forensics platform for disk image analysis.",
    command: "autopsy",
    category: "forensics",
  },
  {
    id: "binwalk",
    name: "Binwalk",
    description: "Firmware analysis tool for extracting embedded files and executable code.",
    command: "binwalk -e firmware.bin",
    category: "forensics",
  },
  {
    id: "foremost",
    name: "Foremost",
    description: "Data carving tool for recovering files based on headers and footers.",
    command: "foremost -i disk.img -o output",
    category: "forensics",
  },
  {
    id: "exiftool",
    name: "ExifTool",
    description: "Read, write and edit metadata in files.",
    command: "exiftool image.jpg",
    category: "forensics",
  },

  // Wireless tools
  {
    id: "aircrack-ng",
    name: "Aircrack-ng",
    description: "Complete suite for wireless network security assessments.",
    command: "aircrack-ng -b <BSSID> -w wordlist.txt capture.cap",
    category: "wireless",
  },
  {
    id: "wifite",
    name: "Wifite",
    description: "Automated wireless attack tool for multiple encryption types.",
    command: "wifite --wpa",
    category: "wireless",
  },
  {
    id: "kismet",
    name: "Kismet",
    description: "Wireless network detector, sniffer, and IDS.",
    command: "kismet -c wlan0",
    category: "wireless",
  },
  {
    id: "reaver",
    name: "Reaver",
    description: "Brute force attack tool against WPS PIN.",
    command: "reaver -i wlan0 -b <BSSID> -vv",
    category: "wireless",
  },

  // Password cracking
  {
    id: "hydra",
    name: "Hydra",
    description: "Fast and flexible online password cracking tool.",
    command: "hydra -l <username> -P wordlist.txt <target_ip> ssh",
    category: "password-cracking",
  },
  {
    id: "john",
    name: "John the Ripper",
    description: "Fast password cracker for multiple hash types.",
    command: "john --format=raw-md5 hashes.txt",
    category: "password-cracking",
  },
  {
    id: "hashcat",
    name: "Hashcat",
    description: "Advanced CPU/GPU based password recovery utility.",
    command: "hashcat -m 0 -a 0 hashes.txt wordlist.txt",
    category: "password-cracking",
  },
  {
    id: "crunch",
    name: "Crunch",
    description: "Wordlist generator with specified character sets.",
    command: "crunch 8 10 abcdefghijklmnopqrstuvwxyz -o wordlist.txt",
    category: "password-cracking",
  },

  // Exploitation
  {
    id: "metasploit",
    name: "Metasploit Framework",
    description: "Advanced open-source platform for developing, testing, and executing exploits.",
    command: "msfconsole",
    category: "exploitation",
  },
  {
    id: "searchsploit",
    name: "SearchSploit",
    description: "Command-line search tool for Exploit-DB.",
    command: "searchsploit apache 2.4",
    category: "exploitation",
  },
  {
    id: "beef-xss",
    name: "BeEF XSS Framework",
    description: "Browser exploitation framework for testing XSS vulnerabilities.",
    command: "beef-xss",
    category: "exploitation",
  },
  {
    id: "sqlmap",
    name: "SQLMap",
    description: "Automated SQL injection and database takeover tool.",
    command: "sqlmap -u 'https://<target_domain>/page.php?id=1' --dbs",
    category: "exploitation",
  },

  // Post-exploitation
  {
    id: "crackmapexec",
    name: "CrackMapExec",
    description: "Post-exploitation tool for Windows/Active Directory environments.",
    command: "crackmapexec smb <target_ip> -u <username> -p <password>",
    category: "post-exploitation",
  },
  {
    id: "empire",
    name: "Empire",
    description: "PowerShell and Python post-exploitation agent.",
    command: "empire",
    category: "post-exploitation",
  },
  {
    id: "bloodhound",
    name: "BloodHound",
    description: "Active Directory reconnaissance tool for identifying attack paths.",
    command: "bloodhound-python -d <domain> -u <username> -p <password> -c All",
    category: "post-exploitation",
  },
  {
    id: "mimikatz",
    name: "Mimikatz",
    description: "Windows credential dumping tool.",
    command: 'mimikatz.exe "privilege::debug" "sekurlsa::logonpasswords" exit',
    category: "post-exploitation",
  },
]

