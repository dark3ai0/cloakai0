import { TargetManager } from "@/lib/target-manager"

type OutputCallback = (output: string) => void
export type LinuxDistro = "alpine" | "kali" | "openwrt" | "parrot"

export class TerminalEngine {
  private outputCallback: OutputCallback | null = null
  private isOllamaInstalled = false
  private runningModels: string[] = []
  private currentDir = "/home/user"
  private targetManager: TargetManager
  private linuxDistro: LinuxDistro = "kali" // Default to Kali
  private apiKey: string | undefined
  private commandHistory: string[] = []
  private historyIndex = -1

  constructor(targetManager?: TargetManager, apiKey?: string) {
    this.targetManager = targetManager || new TargetManager()
    this.apiKey = apiKey
  }

  onOutput(callback: OutputCallback) {
    this.outputCallback = callback
  }

  private output(text: string) {
    if (this.outputCallback) {
      this.outputCallback(text)
    }
  }

  public setDistro(distro: LinuxDistro) {
    this.linuxDistro = distro
  }

  public getDistro(): LinuxDistro {
    return this.linuxDistro
  }

  // Add the missing getTargetManager method
  public getTargetManager(): TargetManager {
    return this.targetManager
  }

  // Add a method to check if Ollama is active
  public isOllamaActive(): boolean {
    return this.isOllamaInstalled && this.runningModels.length > 0
  }

  async execute(command: string) {
    // Replace any target placeholders in the command
    const processedCommand = this.targetManager.replaceTargetPlaceholders(command)
    const trimmedCommand = processedCommand.trim()

    // Split the command into parts
    const parts = this.parseCommand(trimmedCommand)
    const mainCommand = parts[0]

    // Add to command history
    this.addToHistory(trimmedCommand)

    // Handle command execution
    switch (mainCommand) {
      case "set-target":
        this.handleSetTarget(parts.slice(1))
        break

      case "show-target":
        this.showTargetInfo()
        break

      case "change-distro":
        this.handleChangeDistro(parts.slice(1))
        break

      case "clear":
        this.output("Terminal cleared")
        break

      case "help":
        this.showHelp()
        break

      case "ls":
        await this.executeRealCommand("ls", parts.slice(1))
        break

      case "cd":
        this.changeDirectory(parts[1])
        break

      case "pwd":
        this.output(this.currentDir)
        break

      case "echo":
        this.output(parts.slice(1).join(" ").replace(/"/g, "").replace(/'/g, ""))
        break

      case "curl":
        if (parts.includes("https://ollama.com/install.sh")) {
          this.output("Installing Ollama...")
          this.output("Ollama has been installed successfully.")
          this.isOllamaInstalled = true
        } else {
          await this.executeRealCommand("curl", parts.slice(1))
        }
        break

      case "ollama":
        this.handleOllama(parts.slice(1))
        break

      case "nmap":
      case "dirb":
      case "sqlmap":
      case "nikto":
      case "whois":
      case "theHarvester":
      case "gobuster":
      case "wpscan":
        await this.executeRealCommand(mainCommand, parts.slice(1))
        break

      default:
        if (trimmedCommand.includes("&&")) {
          // Handle command chains
          const commands = trimmedCommand.split("&&").map((cmd) => cmd.trim())
          for (const cmd of commands) {
            await this.execute(cmd)
          }
        } else if (trimmedCommand.includes("|")) {
          // Handle pipes
          this.output(`Command piping not fully implemented: ${trimmedCommand}`)
        } else {
          this.output(`Command not found: ${mainCommand}`)
        }
    }
  }

  private async executeRealCommand(command: string, args: string[]) {
    try {
      // In a real implementation, this would execute the command on the server
      // For now, we'll simulate some basic command outputs
      this.output(`Executing: ${command} ${args.join(" ")}`)

      // Simulate a delay for realism
      await new Promise((resolve) => setTimeout(resolve, 500))

      switch (command) {
        case "ls":
          this.output("file1.txt  file2.txt  directory1/  directory2/")
          break
        case "nmap":
          this.output(`Starting Nmap scan for ${args[args.length - 1]}...`)
          this.output("Scan in progress...")
          await new Promise((resolve) => setTimeout(resolve, 1500))
          this.output("Scan complete. Found 3 open ports.")
          break
        case "whois":
          this.output(`WHOIS information for ${args[0]}:`)
          this.output("Domain Name: EXAMPLE.COM")
          this.output("Registry Domain ID: 2336799_DOMAIN_COM-VRSN")
          this.output("Registrar WHOIS Server: whois.example.com")
          this.output("Updated Date: 2023-01-01T00:00:00Z")
          break
        default:
          this.output(`Command ${command} executed with arguments: ${args.join(" ")}`)
      }
    } catch (error) {
      this.output(`Error executing command: ${error}`)
    }
  }

  private handleSetTarget(args: string[]) {
    if (args.length < 2) {
      this.output("Usage: set-target [ip|domain|username|email|phone] value")
      return
    }

    const field = args[0].toLowerCase()
    const value = args[1]

    switch (field) {
      case "ip":
        this.targetManager.updateField("ip", value)
        this.output(`Target IP set to: ${value}`)
        break
      case "domain":
        this.targetManager.updateField("domain", value)
        this.output(`Target domain set to: ${value}`)
        break
      case "username":
        this.targetManager.updateField("username", value)
        this.output(`Target username set to: ${value}`)
        break
      case "email":
        this.targetManager.updateField("email", value)
        this.output(`Target email set to: ${value}`)
        break
      case "phone":
        this.targetManager.updateField("phoneNumber", value)
        this.output(`Target phone number set to: ${value}`)
        break
      default:
        this.output(`Unknown target field: ${field}`)
    }
  }

  private showTargetInfo() {
    const target = this.targetManager.getTarget()
    this.output("Current Target Information:")
    if (target.ip) this.output(`  IP: ${target.ip}`)
    if (target.domain) this.output(`  Domain: ${target.domain}`)
    if (target.username) this.output(`  Username: ${target.username}`)
    if (target.email) this.output(`  Email: ${target.email}`)
    if (target.phoneNumber) this.output(`  Phone: ${target.phoneNumber}`)

    if (!target.ip && !target.domain && !target.username && !target.email && !target.phoneNumber) {
      this.output("  No target information set")
      this.output("  Use 'set-target [field] [value]' to set target information")
    }
  }

  private handleChangeDistro(args: string[]) {
    if (args.length === 0) {
      this.output(`Current distribution: ${this.linuxDistro}`)
      this.output("Usage: change-distro [alpine|kali]")
      return
    }

    const distro = args[0].toLowerCase()
    if (distro === "alpine" || distro === "kali" || distro === "openwrt" || distro === "parrot") {
      this.setDistro(distro as LinuxDistro)
      this.output(`Switched to ${distro} Linux distribution`)
    } else {
      this.output(`Unknown distribution: ${distro}`)
      this.output("Supported distributions: alpine, kali")
    }
  }

  private parseCommand(command: string): string[] {
    const parts: string[] = []
    let current = ""
    let inQuotes = false
    let quoteChar = ""

    for (let i = 0; i < command.length; i++) {
      const char = command[i]

      if ((char === '"' || char === "'") && (!inQuotes || quoteChar === char)) {
        inQuotes = !inQuotes
        if (inQuotes) quoteChar = char
        continue
      }

      if (char === " " && !inQuotes) {
        if (current) {
          parts.push(current)
          current = ""
        }
        continue
      }

      current += char
    }

    if (current) {
      parts.push(current)
    }

    return parts
  }

  private showHelp() {
    let helpText = "Available commands:\n"

    // Base commands for both distros
    helpText += "- clear: Clear the terminal\n"
    helpText += "- help: Show this help message\n"
    helpText += "- ls: List files\n"
    helpText += "- cd: Change directory\n"
    helpText += "- pwd: Print working directory\n"
    helpText += "- echo: Print text\n"
    helpText += "- curl: Transfer data from or to a server\n"
    helpText += "- ollama: Manage Ollama models\n\n"

    // Target management commands
    helpText += "Target Management:\n"
    helpText += "- set-target [ip|domain|username|email|phone] [value]: Set target information\n"
    helpText += "- show-target: Display current target information\n\n"

    // Distro management
    helpText += "System Management:\n"
    helpText += "- change-distro [alpine|kali]: Change Linux distribution\n\n"

    // Security tools
    helpText += "Security Tools:\n"
    helpText += "- nmap: Network scanning tool\n"
    helpText += "- dirb/gobuster: Web content scanner\n"
    helpText += "- whois: Domain information lookup\n"
    helpText += "- wpscan: WordPress vulnerability scanner\n"

    this.output(helpText)
  }

  private changeDirectory(path: string) {
    if (!path) {
      this.currentDir = "/home/user"
      this.output("Changed directory to: /home/user")
      return
    }

    let newPath = path
    if (!path.startsWith("/")) {
      newPath = `${this.currentDir}/${path}`.replace(/\/\.\//g, "/").replace(/\/[^/]+\/\.\.\//g, "/")
    }

    this.currentDir = newPath
    this.output(`Changed directory to: ${newPath}`)
  }

  private handleOllama(args: string[]) {
    if (!this.isOllamaInstalled) {
      this.output("Error: Ollama is not installed. Run 'curl -fsSL https://ollama.com/install.sh | sh' first.")
      return
    }

    if (args[0] === "run") {
      const modelName = args[1] || "gemma:2b"
      this.output(`Running ${modelName} model...`)
      this.output(`${modelName} model loaded and running. The AI assistant is now powered by OLLAMA ${modelName}.`)
      this.runningModels.push(modelName)
    } else if (args[0] === "list" || args[0] === "ps") {
      if (this.runningModels.length === 0) {
        this.output("No models running")
      } else {
        this.output("NAME      ID        SIZE   MODIFIED")
        this.runningModels.forEach((model) => {
          this.output(`${model}  ${this.generateRandomId()}  1.1 GB  Just now`)
        })
      }
    } else {
      this.output(
        `Usage: ollama <command>\n\nCommands:\n  run       Run a model\n  list      List running models\n  ps        List running models`,
      )
    }
  }

  private generateRandomId(): string {
    return Math.random().toString(36).substring(2, 8)
  }

  public async queryOllama(prompt: string): Promise<string> {
    if (!this.isOllamaInstalled || this.runningModels.length === 0) {
      return "Error: No Ollama models are running. Please start a model first with 'ollama run gemma:2b'."
    }

    // In a real implementation, this would call the Ollama API
    // For now, we'll simulate a response
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Generate a response based on the prompt
    if (prompt.toLowerCase().includes("hello") || prompt.toLowerCase().includes("hi")) {
      return "Hello! I'm your AI assistant powered by Gemma. How can I help you with your cybersecurity tasks today?"
    } else if (prompt.toLowerCase().includes("help")) {
      return "I can help with cybersecurity tools, network scanning, and vulnerability assessment. Try asking about specific tasks like 'How do I scan a website?' or 'What's the best way to enumerate a target?'"
    } else if (prompt.toLowerCase().includes("scan") || prompt.toLowerCase().includes("nmap")) {
      return "For network scanning, Nmap is a powerful tool. You can use commands like:\n\n- Basic scan: `nmap <target_ip>`\n- Service detection: `nmap -sV <target_ip>`\n- Full port scan: `nmap -p- <target_ip>`\n- OS detection: `nmap -O <target_ip>`\n\nRemember to only scan systems you have permission to test."
    } else {
      return `I understand your question about "${prompt}". To provide a helpful response, I'd need more specific details about what you're trying to accomplish. I can help with cybersecurity tools, network scanning, or general terminal commands. Could you provide more context?`
    }
  }

  public addToHistory(command: string): void {
    // Don't add duplicates consecutively
    if (this.commandHistory.length === 0 || this.commandHistory[this.commandHistory.length - 1] !== command) {
      this.commandHistory.push(command)
    }
    this.historyIndex = this.commandHistory.length
  }

  public getPreviousCommand(): string {
    if (this.historyIndex > 0) {
      this.historyIndex--
      return this.commandHistory[this.historyIndex]
    }
    return this.historyIndex === 0 ? this.commandHistory[0] : ""
  }

  public getNextCommand(): string {
    if (this.historyIndex < this.commandHistory.length - 1) {
      this.historyIndex++
      return this.commandHistory[this.historyIndex]
    }
    return ""
  }

  public getRelevantSuggestions(input: string): string[] {
    // Get target information
    const target = this.targetManager.getTarget()
    const hasTargetInfo = !!(target.ip || target.domain || target.username || target.email || target.phoneNumber)

    // Base suggestions
    const suggestions: string[] = []

    // Add target-specific suggestions if available
    if (hasTargetInfo) {
      if (target.ip) {
        suggestions.push(`nmap -sV ${target.ip}`)
        suggestions.push(`nmap -sS -A ${target.ip}`)
      }

      if (target.domain) {
        suggestions.push(`whois ${target.domain}`)
        suggestions.push(`gobuster dir -u http://${target.domain} -w /usr/share/wordlists/dirb/common.txt`)
      }
    }

    // Add context-aware suggestions based on input
    const lowerInput = input.toLowerCase()

    if (lowerInput.includes("scan") || lowerInput.includes("port") || lowerInput.includes("nmap")) {
      suggestions.push("nmap -sV <target_ip>")
      suggestions.push("nmap -p- <target_ip>")
      suggestions.push("nmap -sS -A <target_ip>")
    }

    if (lowerInput.includes("web") || lowerInput.includes("http") || lowerInput.includes("site")) {
      suggestions.push("gobuster dir -u http://<target_domain> -w /usr/share/wordlists/dirb/common.txt")
      suggestions.push("wpscan --url http://<target_domain>")
    }

    // Return unique suggestions
    return Array.from(new Set(suggestions))
  }

  public getCommandHistory(): string[] {
    return this.commandHistory.slice().reverse()
  }

  // Add a new method to handle OS switching
  public async switchOS(os: string): Promise<void> {
    // In a real implementation, this would fetch and load the OS
    this.output(`Switching to ${os}...`)

    await new Promise((resolve) => setTimeout(resolve, 1000))

    switch (os) {
      case "alpine":
        this.setDistro("alpine")
        this.output("Alpine Linux loaded successfully.")
        this.output("Welcome to Alpine Linux 3.18")
        break
      case "kali":
        this.setDistro("kali")
        this.output("Kali Linux loaded successfully.")
        this.output("Welcome to Kali Linux 2023.2")
        break
      case "openwrt":
        this.setDistro("openwrt")
        this.output("OpenWRT loaded successfully.")
        this.output("Welcome to OpenWRT 22.03")
        break
      case "parrot":
        this.setDistro("parrot")
        this.output("Parrot Security OS loaded successfully.")
        this.output("Welcome to Parrot OS 5.3")
        break
      default:
        this.output(`Unknown OS: ${os}`)
        return
    }

    this.output("Type 'help' to see available commands.")
  }
}

