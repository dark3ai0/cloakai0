"use client"

import { useState } from "react"
import { Terminal, Copy, Check, Play, Info } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { Tool, Category } from "@/lib/tools-data"
import { TerminalSandbox } from "@/components/terminal-sandbox"
import { useMobile } from "@/hooks/use-mobile"

interface ToolsDisplayProps {
  categories: Category[]
  tools: Tool[]
}

export function ToolsDisplay({ categories, tools }: ToolsDisplayProps) {
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)
  const [isTerminalOpen, setIsTerminalOpen] = useState(false)
  const [runningCommand, setRunningCommand] = useState<string | null>(null)
  const { isMobile } = useMobile()

  const copyToClipboard = (command: string) => {
    navigator.clipboard.writeText(command)
    setCopiedCommand(command)
    setTimeout(() => setCopiedCommand(null), 2000)
  }

  const executeCommand = (command: string) => {
    setIsTerminalOpen(true)
    setRunningCommand(command)

    // Add a visual feedback for the running command
    setTimeout(() => {
      const event = new CustomEvent("run-command", { detail: command })
      document.dispatchEvent(event)

      // Reset the running state after a short delay
      setTimeout(() => {
        setRunningCommand(null)
      }, 1000)
    }, 100)
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <div className="flex justify-center">
          <Button
            size="lg"
            className="bg-[#2a3552] hover:bg-[#344066] text-[#d4d8e3] flex items-center gap-2 px-6 py-6 rounded-lg shadow-glow transition-all duration-300 hover:shadow-glow-intense"
            onClick={() => setIsTerminalOpen(true)}
          >
            <Terminal size={20} className="text-[#5d7ce9] icon-glow" />
            <span className="text-lg">Open Terminal</span>
          </Button>
        </div>

        <Tabs defaultValue="grid" className="w-full">
          <div className="flex justify-between items-center mb-4">
            <div className="text-sm text-gray-500 dark:text-gray-400">{tools.length} tools available</div>
            <TabsList>
              <TabsTrigger value="grid">Grid</TabsTrigger>
              <TabsTrigger value="list">List</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="grid" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tools.map((tool) => (
                <Card
                  key={tool.id}
                  className="overflow-hidden bg-[#151c2c] border-[#1e2738] shadow-md hover:shadow-glow transition-all duration-300"
                >
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-lg text-[#d4d8e3]">{tool.name}</h3>
                      <Badge variant="outline" className="bg-[#2a3552] text-[#8a92a9] border-[#1e2738]">
                        {getCategoryName(categories, tool.category)}
                      </Badge>
                    </div>
                    <p className="text-[#8a92a9] text-sm mb-4">{tool.description}</p>
                    <div className="bg-[#0a0e17] rounded-md p-3 relative group border border-[#1e2738]">
                      <div className="flex items-center text-xs font-mono overflow-x-auto">
                        <Terminal className="mr-2 flex-shrink-0 text-[#5d7ce9]" size={14} />
                        <code className="text-[#d4d8e3]">{tool.command}</code>
                      </div>
                      <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className={`h-6 w-6 transition-all ${runningCommand === tool.command ? "bg-[#193a3a] text-[#4ade80] icon-glow" : "hover:text-[#5d7ce9] hover:icon-glow"}`}
                              onClick={() => executeCommand(tool.command)}
                            >
                              <Play size={14} className={runningCommand === tool.command ? "animate-pulse" : ""} />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="left">
                            <p>Run in terminal</p>
                          </TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 hover:text-[#5d7ce9] hover:icon-glow"
                              onClick={() => copyToClipboard(tool.command)}
                            >
                              {copiedCommand === tool.command ? (
                                <Check size={14} className="text-[#4ade80]" />
                              ) : (
                                <Copy size={14} />
                              )}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="left">
                            <p>{copiedCommand === tool.command ? "Copied!" : "Copy command"}</p>
                          </TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 hover:text-[#5d7ce9] hover:icon-glow"
                              onClick={() => {
                                setIsTerminalOpen(true)
                                setTimeout(() => {
                                  const event = new CustomEvent("show-tool-info", {
                                    detail: { name: tool.name, description: tool.description, command: tool.command },
                                  })
                                  document.dispatchEvent(event)
                                }, 100)
                              }}
                            >
                              <Info size={14} />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="left">
                            <p>Show tool info</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="list" className="mt-0">
            <div className="space-y-3">
              {tools.map((tool) => (
                <Card
                  key={tool.id}
                  className="overflow-hidden bg-[#151c2c] border-[#1e2738] shadow-md hover:shadow-glow transition-all duration-300"
                >
                  <div className="p-4">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-[#d4d8e3]">{tool.name}</h3>
                          <Badge variant="outline" className="bg-[#2a3552] text-[#8a92a9] border-[#1e2738]">
                            {getCategoryName(categories, tool.category)}
                          </Badge>
                        </div>
                        <p className="text-[#8a92a9] text-sm">{tool.description}</p>
                      </div>
                      <div className="bg-[#0a0e17] rounded-md p-2 relative group flex-1 md:max-w-md border border-[#1e2738]">
                        <div className="flex items-center text-xs font-mono overflow-x-auto">
                          <Terminal className="mr-2 flex-shrink-0 text-[#5d7ce9]" size={14} />
                          <code className="text-[#d4d8e3]">{tool.command}</code>
                        </div>
                        <div className="absolute right-2 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className={`h-6 w-6 transition-all ${runningCommand === tool.command ? "bg-[#193a3a] text-[#4ade80] icon-glow" : "hover:text-[#5d7ce9] hover:icon-glow"}`}
                                onClick={() => executeCommand(tool.command)}
                              >
                                <Play size={14} className={runningCommand === tool.command ? "animate-pulse" : ""} />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent side="left">
                              <p>Run in terminal</p>
                            </TooltipContent>
                          </Tooltip>

                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 hover:text-[#5d7ce9] hover:icon-glow"
                                onClick={() => copyToClipboard(tool.command)}
                              >
                                {copiedCommand === tool.command ? (
                                  <Check size={14} className="text-[#4ade80]" />
                                ) : (
                                  <Copy size={14} />
                                )}
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent side="left">
                              <p>{copiedCommand === tool.command ? "Copied!" : "Copy command"}</p>
                            </TooltipContent>
                          </Tooltip>

                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 hover:text-[#5d7ce9] hover:icon-glow"
                                onClick={() => {
                                  setIsTerminalOpen(true)
                                  setTimeout(() => {
                                    const event = new CustomEvent("show-tool-info", {
                                      detail: { name: tool.name, description: tool.description, command: tool.command },
                                    })
                                    document.dispatchEvent(event)
                                  }, 100)
                                }}
                              >
                                <Info size={14} />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent side="left">
                              <p>Show tool info</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
        <TerminalSandbox isOpen={isTerminalOpen} onClose={() => setIsTerminalOpen(false)} />
      </div>
    </TooltipProvider>
  )
}

function getCategoryName(categories: Category[], categoryId: string): string {
  const category = categories.find((c) => c.id === categoryId)
  return category ? category.name : categoryId
}

