"use client"

import { useState } from "react"
import { Server, Terminal, Shield, Cpu, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface OSSwitcherProps {
  onSwitchOS: (os: string) => void
}

export function OSSwitcher({ onSwitchOS }: OSSwitcherProps) {
  const [loadingOS, setLoadingOS] = useState<string | null>(null)

  const handleSwitchOS = async (os: string) => {
    setLoadingOS(os)

    // Simulate fetching the OS (in a real implementation, this would be an API call)
    setTimeout(() => {
      onSwitchOS(os)
      setLoadingOS(null)

      // Dispatch an event to notify the terminal
      const event = new CustomEvent("os-switched", {
        detail: { os },
      })
      document.dispatchEvent(event)
    }, 1500)
  }

  const operatingSystems = [
    { id: "alpine", name: "Alpine Linux", icon: <Terminal size={16} />, color: "bg-blue-900 hover:bg-blue-800" },
    { id: "kali", name: "Kali Linux", icon: <Shield size={16} />, color: "bg-purple-900 hover:bg-purple-800" },
    { id: "openwrt", name: "OpenWRT", icon: <Server size={16} />, color: "bg-orange-900 hover:bg-orange-800" },
    { id: "parrot", name: "Parrot OS", icon: <Cpu size={16} />, color: "bg-green-900 hover:bg-green-800" },
  ]

  return (
    <TooltipProvider>
      <div className="flex items-center space-x-1">
        {operatingSystems.map((os) => (
          <Tooltip key={os.id}>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 rounded-full ${os.color} text-white`}
                onClick={() => handleSwitchOS(os.id)}
                disabled={loadingOS !== null}
              >
                {loadingOS === os.id ? <Loader2 size={16} className="animate-spin" /> : os.icon}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <p>Switch to {os.name}</p>
            </TooltipContent>
          </Tooltip>
        ))}
      </div>
    </TooltipProvider>
  )
}

