"use client"

import type React from "react"

import { useState, useEffect, useRef, type FormEvent } from "react"
import {
  Bot,
  Sparkles,
  Play,
  X,
  MessageSquare,
  ThumbsUp,
  Send,
  Maximize2,
  Minimize2,
  Lightbulb,
  History,
  Trash2,
  User,
  Command,
  CornerRightDown,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useMobile } from "@/hooks/use-mobile"
import type { TerminalEngine } from "@/lib/terminal-engine"
import type { Target } from "@/lib/target-manager"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface TerminalAIAssistantProps {
  input: string
  history: Array<{ type: "input" | "output"; content: string }>
  onSuggestCommand: (command: string) => void
  onExecuteCommand: (command: string) => void
  terminalEngine: TerminalEngine
}

type AssistantMessage = {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  type?: "suggestion" | "explanation" | "answer" | "command" | "memory"
  commands?: string[]
  isLoading?: boolean
  timestamp?: number
}

export function TerminalAIAssistant({
  input,
  history,
  onSuggestCommand,
  onExecuteCommand,
  terminalEngine,
}: TerminalAIAssistantProps) {
  // Change default state to closed
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<AssistantMessage[]>([])
  const [isThinking, setIsThinking] = useState(false)
  const [lastProcessedInput, setLastProcessedInput] = useState("")
  const [assistantInput, setAssistantInput] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [target, setTarget] = useState<Target>(() => {
    if (terminalEngine && terminalEngine.getTargetManager) {
      return terminalEngine.getTargetManager().getTarget()
    }
    return { ip: "", domain: "", username: "", email: "", phoneNumber: "" }
  })
  const { isMobile } = useMobile()
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  // New state for enhanced features
  const [position, setPosition] = useState({
    x: isMobile ? Math.max(10, (window.innerWidth - 380) / 2) : Math.max(10, window.innerWidth - 420),
    y: isMobile ? 80 : 80,
  })
  const [size, setSize] = useState({ width: 380, height: 500 })
  const [isDragging, setIsDragging] = useState(false)
  const [isResizing, setIsResizing] = useState(false)
  const [resizeDirection, setResizeDirection] = useState<string | null>(null)
  const [isPinned, setIsPinned] = useState(false)
  const [activeTab, setActiveTab] = useState("chat")
  const [suggestedCommands, setSuggestedCommands] = useState<string[]>([])
  const [memories, setMemories] = useState<AssistantMessage[]>([])
  const dragStartPos = useRef({ x: 0, y: 0 })
  const dragStartSize = useRef({ width: 0, height: 0 })
  const [showCommandCategories, setShowCommandCategories] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const chatInputRef = useRef<HTMLInputElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const [chatInput, setChatInput] = useState("")
  const [chatHistory, setChatHistory] = useState<Array<{ role: "user" | "assistant"; content: string }>>([
    {
      role: "assistant",
      content: "Hello! I'm your AI assistant. How can I help you with your cybersecurity tasks today?",
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [commandHistory, setCommandHistory] = useState<string[]>([])

  // New state for touch support
  const [touchStartPos, setTouchStartPos] = useState({ x: 0, y: 0 })
  const [touchStartSize, setTouchStartSize] = useState({ width: 0, height: 0 })
  const [isTouchResizing, setIsTouchResizing] = useState(false)
  const [touchResizeCorner, setTouchResizeCorner] = useState<string | null>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Listen for target updates
  useEffect(() => {
    if (terminalEngine && terminalEngine.getTargetManager) {
      const targetManager = terminalEngine.getTargetManager()
      targetManager.addListener((newTarget) => {
        setTarget({ ...newTarget })
      })
    }
  }, [terminalEngine])

  // Process input changes to generate suggestions
  useEffect(() => {
    if (input && input !== lastProcessedInput && input.length > 3) {
      const debounceTimer = setTimeout(() => {
        generateSuggestion(input)
        setLastProcessedInput(input)
      }, 500)

      return () => clearTimeout(debounceTimer)
    }
  }, [input, lastProcessedInput])

  // Load saved messages from localStorage
  useEffect(() => {
    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      try {
        const savedMessages = localStorage.getItem("ai_assistant_messages")
        if (savedMessages) {
          setMessages(JSON.parse(savedMessages))
        }

        const savedMemories = localStorage.getItem("ai_assistant_memories")
        if (savedMemories) {
          setMemories(JSON.parse(savedMemories))
        }
      } catch (error) {
        console.error("Error loading saved messages:", error)
      }
    }
  }, [])

  // Save messages to localStorage when they change
  useEffect(() => {
    if (typeof window !== "undefined" && typeof localStorage !== "undefined" && messages.length > 0) {
      try {
        localStorage.setItem("ai_assistant_messages", JSON.stringify(messages))
      } catch (error) {
        console.error("Error saving messages:", error)
      }
    }
  }, [messages])

  // Save memories to localStorage when they change
  useEffect(() => {
    if (typeof window !== "undefined" && typeof localStorage !== "undefined" && memories.length > 0) {
      try {
        localStorage.setItem("ai_assistant_memories", JSON.stringify(memories))
      } catch (error) {
        console.error("Error saving memories:", error)
      }
    }
  }, [memories])

  // Process history changes to provide context-aware help and detect Ollama status
  useEffect(() => {
    if (history.length > 0) {
      const lastEntry = history[history.length - 1]

      // Check if Ollama is running
      if (lastEntry.type === "output" && lastEntry.content.includes("model loaded and running")) {
        // Add a welcome message when Ollama is first activated
        setTimeout(() => {
          addMessage({
            id: Date.now().toString(),
            role: "assistant",
            content:
              "I'm now powered by OLLAMA Gemma3! Ask me anything about cybersecurity, skip tracing, or property research.",
            type: "suggestion",
            timestamp: Date.now(),
          })
          // Don't automatically open the assistant
          // setIsOpen(true)
        }, 1000)
      }

      // If the last entry was a command not found error
      if (lastEntry.type === "output" && lastEntry.content.includes("command not found")) {
        const commandAttempted = history[history.length - 2]?.content
        if (commandAttempted) {
          suggestAlternativeCommand(commandAttempted)
        }
      }

      // If target information was updated
      if (lastEntry.type === "input" && lastEntry.content.startsWith("set-target")) {
        setTimeout(() => {
          const commands = [
            `nmap ${target.ip || target.domain}`,
            `whois ${target.domain}`,
            `theHarvester -d ${target.domain} -l 500 -b all`,
          ].filter((cmd) => !cmd.includes("undefined"))

          setSuggestedCommands(commands)

          addMessage({
            id: Date.now().toString(),
            role: "assistant",
            content:
              "Target information updated! You can now run commands against this target. Try running a scan or lookup.",
            type: "suggestion",
            commands: commands,
            timestamp: Date.now(),
          })
          // Don't automatically open the assistant
          // setIsOpen(true)
        }, 1000)
      }

      // Add the last command to memory if it's significant
      if (lastEntry.type === "input" && isSignificantCommand(lastEntry.content)) {
        addToMemory(lastEntry.content)
      }
    }
  }, [history, target])

  // Listen for tool info events
  useEffect(() => {
    const handleToolInfo = (event: CustomEvent) => {
      const { name, description, command } = event.detail
      if (name && description && command) {
        addMessage({
          id: Date.now().toString(),
          role: "system",
          content: `Tool Information: ${name}

${description}

Command: \`${command}\``,
          type: "explanation",
          commands: [command],
          timestamp: Date.now(),
        })
        setIsOpen(true)
      }
    }

    document.addEventListener("show-tool-info" as any, handleToolInfo as EventListener)

    return () => {
      document.removeEventListener("show-tool-info" as any, handleToolInfo as EventListener)
    }
  }, [])

  // Handle dragging and resizing
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging && !isPinned) {
        const dx = e.clientX - dragStartPos.current.x
        const dy = e.clientY - dragStartPos.current.y

        setPosition({
          x: Math.max(0, Math.min(window.innerWidth - size.width, position.x + dx)),
          y: Math.max(0, Math.min(window.innerHeight - size.height, position.y + dy)),
        })

        dragStartPos.current = { x: e.clientX, y: e.clientY }
      } else if (isResizing) {
        const dx = e.clientX - dragStartPos.current.x
        const dy = e.clientY - dragStartPos.current.y

        if (resizeDirection === "se") {
          setSize({
            width: Math.max(300, Math.min(800, dragStartSize.current.width + dx)),
            height: Math.max(300, Math.min(800, dragStartSize.current.height + dy)),
          })
        } else if (resizeDirection === "e") {
          setSize({
            width: Math.max(300, Math.min(800, dragStartSize.current.width + dx)),
            height: size.height,
          })
        } else if (resizeDirection === "s") {
          setSize({
            width: size.width,
            height: Math.max(300, Math.min(800, dragStartSize.current.height + dy)),
          })
        }
      }
    }

    const handleMouseUp = () => {
      setIsDragging(false)
      setIsResizing(false)
      setResizeDirection(null)
    }

    if (isDragging || isResizing) {
      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }
  }, [isDragging, isResizing, position, size, isPinned, resizeDirection])

  // Add touch event handlers for mobile resizing
  useEffect(() => {
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length !== 1) return

      const touch = e.touches[0]

      if (isTouchResizing && touchResizeCorner) {
        const dx = touch.clientX - touchStartPos.x
        const dy = touch.clientY - touchStartPos.y

        if (touchResizeCorner === "se") {
          setSize({
            width: Math.max(300, Math.min(window.innerWidth - 20, touchStartSize.width + dx)),
            height: Math.max(300, Math.min(window.innerHeight - 20, touchStartSize.height + dy)),
          })
        } else if (touchResizeCorner === "e") {
          setSize({
            width: Math.max(300, Math.min(window.innerWidth - 20, touchStartSize.width + dx)),
            height: size.height,
          })
        } else if (touchResizeCorner === "s") {
          setSize({
            width: size.width,
            height: Math.max(300, Math.min(window.innerHeight - 20, touchStartSize.height + dy)),
          })
        }

        e.preventDefault()
      } else if (isDragging) {
        const dx = touch.clientX - touchStartPos.x
        const dy = touch.clientY - touchStartPos.y

        setPosition({
          x: Math.max(0, Math.min(window.innerWidth - size.width, position.x + dx)),
          y: Math.max(0, Math.min(window.innerHeight - size.height, position.y + dy)),
        })

        setTouchStartPos({ x: touch.clientX, y: touch.clientY })
        e.preventDefault()
      }
    }

    const handleTouchEnd = () => {
      setIsTouchResizing(false)
      setTouchResizeCorner(null)
      setIsDragging(false)
    }

    if (isTouchResizing || isDragging) {
      document.addEventListener("touchmove", handleTouchMove, { passive: false })
      document.addEventListener("touchend", handleTouchEnd)
      document.addEventListener("touchcancel", handleTouchEnd)
    }

    return () => {
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("touchend", handleTouchEnd)
      document.removeEventListener("touchcancel", handleTouchEnd)
    }
  }, [isTouchResizing, isDragging, touchResizeCorner, touchStartPos, touchStartSize, position, size])

  // Add a useEffect to adjust position when window is resized
  useEffect(() => {
    const handleResize = () => {
      // Only adjust if not being dragged
      if (!isDragging) {
        setPosition((prev) => ({
          x: Math.min(prev.x, window.innerWidth - size.width),
          y: Math.min(prev.y, window.innerHeight - size.height),
        }))
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [size, isDragging])

  useEffect(() => {
    // Update suggestions based on input
    if (terminalEngine) {
      const newSuggestions = terminalEngine.getRelevantSuggestions(input)
      setSuggestions(newSuggestions)
    }
  }, [input, terminalEngine])

  useEffect(() => {
    // Update command history
    if (terminalEngine) {
      const newHistory = terminalEngine.getCommandHistory().slice(0, 10)
      setCommandHistory(newHistory)
    }
  }, [history, terminalEngine])

  useEffect(() => {
    // Scroll chat to bottom when new messages arrive
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [chatHistory])

  const isSignificantCommand = (command: string): boolean => {
    // List of command prefixes that are worth remembering
    const significantPrefixes = [
      "nmap",
      "gobuster",
      "dirb",
      "sqlmap",
      "nikto",
      "wpscan",
      "hydra",
      "john",
      "hashcat",
      "aircrack-ng",
      "metasploit",
      "set-target",
      "whois",
      "theHarvester",
      "sherlock",
      "phoneinfoga",
    ]

    return significantPrefixes.some((prefix) => command.startsWith(prefix))
  }

  const addToMemory = (command: string) => {
    const newMemory: AssistantMessage = {
      id: Date.now().toString(),
      role: "system",
      content: command,
      type: "memory",
      timestamp: Date.now(),
    }

    // Keep only the last 20 memories
    setMemories((prev) => {
      const updated = [newMemory, ...prev].slice(0, 20)
      return updated
    })
  }

  const generateSuggestion = (currentInput: string) => {
    setIsThinking(true)

    // Get target information
    const hasTargetInfo = !!(target.ip || target.domain || target.username || target.email || target.phoneNumber)

    // Simulate AI thinking time
    setTimeout(() => {
      let suggestion: AssistantMessage | null = null

      // Check for questions
      if (
        currentInput.includes("?") ||
        currentInput.toLowerCase().startsWith("how") ||
        currentInput.toLowerCase().startsWith("what") ||
        currentInput.toLowerCase().startsWith("can you")
      ) {
        suggestion = generateAnswerForQuestion(currentInput)
      }
      // Check for specific tool or technique mentions
      else if (
        currentInput.toLowerCase().includes("scan") ||
        currentInput.toLowerCase().includes("nmap") ||
        currentInput.toLowerCase().includes("port")
      ) {
        suggestion = {
          id: Date.now().toString(),
          role: "assistant",
          content: "It looks like you're trying to scan something. Here are some useful scanning commands:",
          type: "command",
          commands: hasTargetInfo
            ? [
                `nmap -sV ${target.ip || target.domain}`,
                `nmap -sS -A ${target.ip || target.domain}`,
                `nikto -h ${target.domain || target.ip}`,
              ]
            : ["nmap -sV <target_ip>", "nmap -sS -A <target_ip>", "nikto -h <target_domain>"],
          timestamp: Date.now(),
        }
      } else if (
        currentInput.toLowerCase().includes("property") ||
        currentInput.toLowerCase().includes("owner") ||
        currentInput.toLowerCase().includes("real estate")
      ) {
        suggestion = {
          id: Date.now().toString(),
          role: "assistant",
          content: "Looking for property information? Try these commands:",
          type: "command",
          commands:
            hasTargetInfo && target.domain
              ? [
                  `curl -s 'https://api.estated.com/property/v4?token=YOUR_API_KEY&address=${target.domain}'`,
                  `curl -s 'https://api.propertyiq.com/v1/properties?address=${target.domain}&api_key=YOUR_API_KEY'`,
                ]
              : [
                  "curl -s 'https://api.estated.com/property/v4?token=YOUR_API_KEY&address=<street_address>'",
                  "curl -s 'https://api.propertyiq.com/v1/properties?address=<address>&api_key=YOUR_API_KEY'",
                ],
          timestamp: Date.now(),
        }
      } else if (
        currentInput.toLowerCase().includes("phone") ||
        currentInput.toLowerCase().includes("email") ||
        currentInput.toLowerCase().includes("person")
      ) {
        suggestion = {
          id: Date.now().toString(),
          role: "assistant",
          content: "Looking for person information? These commands might help:",
          type: "command",
          commands: hasTargetInfo
            ? [
                target.phoneNumber ? `phoneinfoga scan -n ${target.phoneNumber}` : "phoneinfoga scan -n <phone_number>",
                target.domain
                  ? `theHarvester -d ${target.domain} -l 500 -b all`
                  : "theHarvester -d <domain_name> -l 500 -b all",
                target.username ? `sherlock ${target.username}` : "sherlock <username>",
              ]
            : [
                "phoneinfoga scan -n <phone_number>",
                "theHarvester -d <domain_name> -l 500 -b all",
                "sherlock <username>",
              ],
          timestamp: Date.now(),
        }
      } else if (
        currentInput.toLowerCase().includes("ollama") ||
        currentInput.toLowerCase().includes("gemma") ||
        currentInput.toLowerCase().includes("ai")
      ) {
        suggestion = {
          id: Date.now().toString(),
          role: "assistant",
          content: "Want to use OLLAMA Gemma3? Here are the commands you need:",
          type: "command",
          commands: ["curl -fsSL https://ollama.com/install.sh | sh", "ollama run gemma3:1b"],
          timestamp: Date.now(),
        }
      } else if (
        currentInput.toLowerCase().includes("target") ||
        currentInput.toLowerCase().includes("set ip") ||
        currentInput.toLowerCase().includes("set domain")
      ) {
        suggestion = {
          id: Date.now().toString(),
          role: "assistant",
          content: "You can set target information with these commands:",
          type: "command",
          commands: [
            "set-target ip 192.168.1.1",
            "set-target domain example.com",
            "set-target username johndoe",
            "show-target",
          ],
          timestamp: Date.now(),
        }
      } else if (
        currentInput.toLowerCase().includes("kali") ||
        currentInput.toLowerCase().includes("linux") ||
        currentInput.toLowerCase().includes("alpine") ||
        currentInput.toLowerCase().includes("distro") ||
        currentInput.toLowerCase().includes("os")
      ) {
        suggestion = {
          id: Date.now().toString(),
          role: "assistant",
          content: "You can change the Linux distribution with these commands:",
          type: "command",
          commands: ["change-distro kali", "change-distro alpine"],
          timestamp: Date.now(),
        }
      }

      if (suggestion) {
        addMessage(suggestion)
        // Don't automatically open the assistant
        // setIsOpen(true)
      }

      setIsThinking(false)
    }, 800)
  }

  const generateAnswerForQuestion = (question: string): AssistantMessage => {
    const lowerQuestion = question.toLowerCase()
    const hasTargetInfo = !!(target.ip || target.domain || target.username || target.email || target.phoneNumber)

    // Target related questions
    if (lowerQuestion.includes("target") || lowerQuestion.includes("set ip") || lowerQuestion.includes("set domain")) {
      return {
        id: Date.now().toString(),
        role: "assistant",
        content: "You can manage target information with these commands:",
        type: "command",
        commands: [
          "set-target ip 192.168.1.1",
          "set-target domain example.com",
          "set-target username johndoe",
          "set-target email user@example.com",
          "set-target phone +1234567890",
          "show-target",
        ],
        timestamp: Date.now(),
      }
    }

    // OS/Distro related questions
    if (
      lowerQuestion.includes("kali") ||
      lowerQuestion.includes("linux") ||
      lowerQuestion.includes("alpine") ||
      lowerQuestion.includes("distro") ||
      lowerQuestion.includes("os") ||
      lowerQuestion.includes("change os")
    ) {
      return {
        id: Date.now().toString(),
        role: "assistant",
        content: "You can change the Linux distribution with these commands:",
        type: "command",
        commands: ["change-distro kali", "change-distro alpine"],
        timestamp: Date.now(),
      }
    }

    // Ollama related questions
    if (lowerQuestion.includes("ollama") || lowerQuestion.includes("gemma") || lowerQuestion.includes("ai model")) {
      return {
        id: Date.now().toString(),
        role: "assistant",
        content:
          "To use OLLAMA Gemma3, you need to first install Ollama and then run the Gemma3 model. Here are the commands:",
        type: "command",
        commands: ["curl -fsSL https://ollama.com/install.sh | sh", "ollama run gemma3:1b"],
        timestamp: Date.now(),
      }
    }

    // Property research questions
    if (
      lowerQuestion.includes("property") ||
      lowerQuestion.includes("real estate") ||
      lowerQuestion.includes("owner")
    ) {
      if (lowerQuestion.includes("find") || lowerQuestion.includes("search")) {
        return {
          id: Date.now().toString(),
          role: "assistant",
          content:
            "To find property information, you can use APIs like Estated, PropertyIQ, or ATTOM Data. Here's a command to look up property details:",
          type: "command",
          commands:
            hasTargetInfo && target.domain
              ? [`curl -s 'https://api.estated.com/property/v4?token=YOUR_API_KEY&address=${target.domain}'`]
              : ["curl -s 'https://api.estated.com/property/v4?token=YOUR_API_KEY&address=<street_address>'"],
          timestamp: Date.now(),
        }
      }
      return {
        id: Date.now().toString(),
        role: "assistant",
        content:
          "For property research, we have several tools available. You can look up property details, owner information, neighborhood demographics, and school information. Would you like me to show you specific commands for any of these?",
        type: "explanation",
        timestamp: Date.now(),
      }
    }

    // Cybersecurity questions
    if (
      lowerQuestion.includes("scan") ||
      lowerQuestion.includes("vulnerability") ||
      lowerQuestion.includes("security")
    ) {
      return {
        id: Date.now().toString(),
        role: "assistant",
        content:
          "For security scanning, you can use tools like Nmap for port scanning, Nikto for web vulnerability scanning, or Dirb for directory brute forcing. Here's a basic Nmap scan command:",
        type: "command",
        commands: hasTargetInfo
          ? [
              `nmap -sV ${target.ip || target.domain}`,
              `nikto -h ${target.domain || target.ip}`,
              `dirb https://${target.domain || "example.com"}`,
            ]
          : ["nmap -sV <target_ip>", "nikto -h <target_domain>", "dirb https://<target_domain>"],
        timestamp: Date.now(),
      }
    }

    // Skip tracing questions
    if (
      lowerQuestion.includes("skip trac") ||
      lowerQuestion.includes("find person") ||
      lowerQuestion.includes("locate")
    ) {
      return {
        id: Date.now().toString(),
        role: "assistant",
        content:
          "For skip tracing, you can use tools like PhoneInfoga for phone lookups, Sherlock for social media profiles, or theHarvester for email discovery. Here's a command to search for social media profiles:",
        type: "command",
        commands: hasTargetInfo
          ? [
              target.username ? `sherlock ${target.username}` : "sherlock <username>",
              target.email
                ? `theHarvester -d ${target.email.split("@")[1]} -l 500 -b all`
                : "theHarvester -d <domain_name> -l 500 -b all",
              target.phoneNumber ? `phoneinfoga scan -n ${target.phoneNumber}` : "phoneinfoga scan -n <phone_number>",
            ]
          : [
              "sherlock <username>",
              "theHarvester -d <domain_name> -l 500 -b all",
              "phoneinfoga scan -n <phone_number>",
            ],
        timestamp: Date.now(),
      }
    }

    // General help
    return {
      id: Date.now().toString(),
      role: "assistant",
      content:
        "I can help with cybersecurity tools, property research, and skip tracing. Try asking about specific tasks like 'How do I scan a website?' or 'How can I find property owner information?'",
      type: "answer",
      timestamp: Date.now(),
    }
  }

  const suggestAlternativeCommand = (failedCommand: string) => {
    const lowerCommand = failedCommand.toLowerCase()
    let suggestion: AssistantMessage | null = null

    // Common typos and alternatives
    if (lowerCommand.includes("nmpa") || lowerCommand.includes("nmp")) {
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content: "It looks like you might be trying to use Nmap. Here's the correct command:",
        type: "command",
        commands: target.ip || target.domain ? [`nmap -sV ${target.ip || target.domain}`] : ["nmap -sV <target_ip>"],
        timestamp: Date.now(),
      }
    } else if (lowerCommand.includes("whios") || lowerCommand.includes("whos")) {
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content: "It looks like you might be trying to use Whois. Here's the correct command:",
        type: "command",
        commands: target.domain ? [`whois ${target.domain}`] : ["whois <domain_name>"],
        timestamp: Date.now(),
      }
    } else if (lowerCommand.includes("curl") || lowerCommand.includes("api")) {
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content:
          "For API requests with curl, make sure to include the full URL and any required headers. Here's an example:",
        type: "command",
        commands: ["curl -s 'https://api.example.com/endpoint' -H 'Authorization: Bearer YOUR_API_KEY' | jq"],
        timestamp: Date.now(),
      }
    } else if (lowerCommand.includes("olama") || lowerCommand.includes("ollma") || lowerCommand.includes("gema")) {
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content: "It looks like you might be trying to use Ollama. Here are the correct commands:",
        type: "command",
        commands: ["curl -fsSL https://ollama.com/install.sh | sh", "ollama run gemma3:1b"],
        timestamp: Date.now(),
      }
    } else if (
      lowerCommand.includes("set-trget") ||
      lowerCommand.includes("set-target") ||
      lowerCommand.includes("target")
    ) {
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content: "It looks like you might be trying to set target information. Here are the correct commands:",
        type: "command",
        commands: ["set-target ip 192.168.1.1", "set-target domain example.com", "show-target"],
        timestamp: Date.now(),
      }
    } else if (
      lowerCommand.includes("change-distro") ||
      lowerCommand.includes("kali") ||
      lowerCommand.includes("alpine")
    ) {
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content: "It looks like you might be trying to change the Linux distribution. Here are the correct commands:",
        type: "command",
        commands: ["change-distro kali", "change-distro alpine"],
        timestamp: Date.now(),
      }
    } else {
      // Generic suggestion
      suggestion = {
        id: Date.now().toString(),
        role: "assistant",
        content:
          "Command not found. Would you like me to help you find the right command? Try describing what you're trying to do.",
        type: "suggestion",
        timestamp: Date.now(),
      }
    }

    if (suggestion) {
      addMessage(suggestion)
      // Don't automatically open the assistant
      // setIsOpen(true)
    }
  }

  const addMessage = (message: AssistantMessage) => {
    setMessages((prev) => [...prev, message])
  }

  const clearMessages = () => {
    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      localStorage.removeItem("ai_assistant_messages")
    }
    setMessages([])
  }

  const clearMemories = () => {
    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      localStorage.removeItem("ai_assistant_memories")
    }
    setMemories([])
  }

  const handleFeedback = (positive: boolean) => {
    // In a real implementation, this would send feedback to improve the model
    alert(`Thank you for your ${positive ? "positive" : "negative"} feedback!`)
  }

  const handleAssistantSubmit = async (e: FormEvent) => {
    e.preventDefault()

    if (!assistantInput.trim() || isProcessing) return

    // Add user message
    const userMessage: AssistantMessage = {
      id: Date.now().toString(),
      role: "user",
      content: assistantInput,
      timestamp: Date.now(),
    }

    addMessage(userMessage)

    // Add loading message
    const loadingMessageId = Date.now().toString()
    const loadingMessage: AssistantMessage = {
      id: loadingMessageId,
      role: "assistant",
      content: "",
      isLoading: true,
      timestamp: Date.now(),
    }

    addMessage(loadingMessage)
    setAssistantInput("")
    setIsProcessing(true)

    try {
      // Get response from Ollama
      const response = await terminalEngine.queryOllama(assistantInput)

      // Replace loading message with response
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === loadingMessageId
            ? {
                id: loadingMessageId,
                role: "assistant",
                content: response,
                type: "answer",
                timestamp: Date.now(),
              }
            : msg,
        ),
      )
    } catch (error) {
      // Handle error
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === loadingMessageId
            ? {
                id: loadingMessageId,
                role: "assistant",
                content: "Sorry, I encountered an error processing your request. Please try again.",
                type: "answer",
                timestamp: Date.now(),
              }
            : msg,
        ),
      )
    } finally {
      setIsProcessing(false)
    }
  }

  const extractCommandsFromMessage = (content: string): string[] => {
    const commands: string[] = []
    const codeBlockRegex = /`([^`]+)`/g
    let match

    while ((match = codeBlockRegex.exec(content)) !== null) {
      commands.push(match[1])
    }

    return commands
  }

  const formatTimestamp = (timestamp?: number): string => {
    if (!timestamp) return ""

    const now = new Date()
    const date = new Date(timestamp)

    // If it's today, just show the time
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }

    // If it's within the last week, show the day name
    const daysDiff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    if (daysDiff < 7) {
      return (
        date.toLocaleDateString([], { weekday: "short" }) +
        " " +
        date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      )
    }

    // Otherwise show the full date
    return date.toLocaleDateString([], { month: "short", day: "numeric" })
  }

  const getSuggestions = () => {
    // Get suggestions based on current input and history
    if (input) {
      return terminalEngine.getRelevantSuggestions(input)
    }

    // Default suggestions
    return [
      "nmap -sV <target_ip>",
      "gobuster dir -u http://<target_domain> -w /usr/share/wordlists/dirb/common.txt",
      "wpscan --url http://<target_domain>",
      "set-target domain example.com",
      "show-target",
    ]
  }

  const getRecentCommands = () => {
    return terminalEngine.getCommandHistory().slice(0, 10)
  }

  // Define renderSuggestionsContent
  const renderSuggestionsContent = () => {
    const suggestions = getSuggestions()
    const recentCommands = getRecentCommands()

    return (
      <ScrollArea className="flex-1 p-3">
        <div className="mb-4">
          <h4 className="text-sm font-medium text-[#d4d8e3] mb-2">Suggested Commands</h4>
          {suggestions.length > 0 ? (
            <ul className="space-y-2">
              {suggestions.map((suggestion, index) => (
                <li key={index} className="flex items-center justify-between">
                  <span className="text-xs text-[#8a92a9]">{suggestion}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 text-[#8a92a9] hover:text-[#d4d8e3] hover:bg-[#2a3552]"
                    onClick={() => onSuggestCommand(suggestion)}
                  >
                    <Play size={12} />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-[#8a92a9]">No suggestions available.</p>
          )}
        </div>

        <div>
          <h4 className="text-sm font-medium text-[#d4d8e3] mb-2">Recent Commands</h4>
          {recentCommands.length > 0 ? (
            <ul className="space-y-2">
              {recentCommands.map((command, index) => (
                <li key={index} className="flex items-center justify-between">
                  <span className="text-xs text-[#8a92a9]">{command}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 text-[#8a92a9] hover:text-[#d4d8e3] hover:bg-[#2a3552]"
                    onClick={() => onSuggestCommand(command)}
                  >
                    <Play size={12} />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-[#8a92a9]">No recent commands.</p>
          )}
        </div>
      </ScrollArea>
    )
  }

  // Define renderMemoryContent
  const renderMemoryContent = () => {
    return (
      <ScrollArea className="flex-1 p-3">
        {memories.length > 0 ? (
          <>
            <div className="flex justify-end mb-2">
              <Button
                variant="ghost"
                size="sm"
                className="h-6 text-xs text-[#8a92a9] hover:text-[#d4d8e3]"
                onClick={clearMemories}
              >
                <Trash2 size={12} className="mr-1" />
                Clear Memories
              </Button>
            </div>
            <ul className="space-y-2">
              {memories.map((memory) => (
                <li key={memory.id} className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-xs text-[#d4d8e3]">{memory.content}</p>
                    <p className="text-[0.6rem] text-[#8a92a9]">{formatTimestamp(memory.timestamp)}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 text-[#8a92a9] hover:text-[#d4d8e3] hover:bg-[#2a3552]"
                    onClick={() => onExecuteCommand(memory.content)}
                  >
                    <Play size={12} />
                  </Button>
                </li>
              ))}
            </ul>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full">
            <History size={48} className="text-[#8a92a9]" />
            <p className="text-sm text-[#8a92a9] mt-2">No memories saved.</p>
          </div>
        )}
      </ScrollArea>
    )
  }

  const handleMouseDown = (e: React.MouseEvent, type: "drag" | "resize", direction?: string) => {
    if (type === "drag") {
      setIsDragging(true)
      dragStartPos.current = { x: e.clientX, y: e.clientY }
    } else if (type === "resize") {
      setIsResizing(true)
      setResizeDirection(direction || null)
      dragStartPos.current = { x: e.clientX, y: e.clientY }
      dragStartSize.current = { width: size.width, height: size.height }
    }
    e.preventDefault()
  }

  // Handle touch start for resizing
  const handleTouchStart = (e: React.TouchEvent, type: "drag" | "resize", corner?: string) => {
    if (e.touches.length !== 1) return

    const touch = e.touches[0]

    if (type === "resize") {
      setIsTouchResizing(true)
      setTouchResizeCorner(corner || null)
      setTouchStartPos({ x: touch.clientX, y: touch.clientY })
      setTouchStartSize({ width: size.width, height: size.height })
    } else if (type === "drag") {
      setIsDragging(true)
      setTouchStartPos({ x: touch.clientX, y: touch.clientY })
    }

    e.preventDefault()
  }

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!chatInput.trim()) return

    // Add user message to chat
    const userMessage = chatInput.trim()
    setChatHistory((prev) => [...prev, { role: "user", content: userMessage }])
    setChatInput("")
    setIsLoading(true)

    try {
      // Check if it's a command execution request
      if (userMessage.startsWith("/")) {
        const command = userMessage.slice(1)
        // Dispatch custom event to run command
        const event = new CustomEvent("run-command", { detail: command })
        document.dispatchEvent(event)

        setChatHistory((prev) => [
          ...prev,
          {
            role: "assistant",
            content: `Executing command: ${command}`,
          },
        ])
      } else {
        // Process with AI
        const response = await terminalEngine.queryOllama(userMessage)
        setChatHistory((prev) => [...prev, { role: "assistant", content: response }])
      }
    } catch (error) {
      setChatHistory((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `Error: ${error instanceof Error ? error.message : String(error)}`,
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    onSuggestCommand(suggestion)
  }

  const handleHistoryClick = (command: string) => {
    onSuggestCommand(command)
  }

  const handleRunCommand = (command: string) => {
    // Dispatch a custom event to run the command
    const event = new CustomEvent("run-command", { detail: command })
    document.dispatchEvent(event)
  }

  if (!isOpen) {
    return (
      <Button
        className="fixed bottom-4 right-4 rounded-full w-12 h-12 flex items-center justify-center bg-[#3b82f6] hover:bg-[#2563eb] text-white shadow-lg"
        onClick={() => setIsOpen(true)}
      >
        <Bot size={24} />
      </Button>
    )
  }

  return (
    <TooltipProvider>
      {/* AI Assistant Toggle Button - Always visible */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className={`fixed bottom-4 right-4 h-12 w-12 rounded-full ${
              terminalEngine.isOllamaActive() ? "bg-[#193a3a]" : "bg-[#2a3552]"
            } text-[#d4d8e3] shadow-glow ${isThinking ? "animate-pulse" : ""}`}
            onClick={() => setIsOpen(!isOpen)}
          >
            {isThinking ? (
              <Sparkles size={22} className="text-[#5d7ce9] icon-glow" />
            ) : (
              <Bot
                size={22}
                className={terminalEngine.isOllamaActive() ? "text-[#4ade80] icon-glow" : "text-[#5d7ce9] icon-glow"}
              />
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="left" className="bg-[#151c2c] border-[#1e2738] text-[#d4d8e3]">
          <p>OLLAMA Gemma3 AI Assistant {terminalEngine.isOllamaActive() ? "(Active)" : "(Inactive)"}</p>
        </TooltipContent>
      </Tooltip>

      {/* AI Assistant Panel */}
      {isOpen && (
        <div
          ref={containerRef}
          className="fixed z-50 bg-[#0f1117] text-[#f7fafc] border border-[#2d3748] rounded-lg shadow-2xl overflow-hidden"
          style={{
            width: `${size.width}px`,
            height: isMinimized ? "auto" : `${size.height}px`,
            left: `${position.x}px`,
            top: `${position.y}px`,
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between p-2 bg-[#1a202c] border-b border-[#2d3748] cursor-move"
            onMouseDown={(e) => handleMouseDown(e, "drag")}
            onTouchStart={(e) => handleTouchStart(e, "drag")}
          >
            <div className="flex items-center gap-2">
              <Bot size={16} className="text-[#3b82f6]" />
              <span className="text-[#f7fafc] font-medium">OLLAMA Gemma3 AI Assistant</span>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-[#a0aec0] hover:text-[#f7fafc] hover:bg-[#2d3748]"
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? <Maximize2 size={14} /> : <Minimize2 size={14} />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-[#a0aec0] hover:text-[#f56565] hover:bg-[#3a1919]"
                onClick={() => setIsOpen(false)}
              >
                <X size={14} />
              </Button>
            </div>
          </div>

          {/* Content */}
          {!isMinimized && (
            <Tabs defaultValue="chat" className="flex flex-col h-[calc(100%-40px)]">
              <TabsList className="grid grid-cols-3 bg-[#1a202c] border-b border-[#2d3748] rounded-none">
                <TabsTrigger
                  value="chat"
                  className="data-[state=active]:bg-[#2d3748] data-[state=active]:text-[#f7fafc]"
                >
                  <MessageSquare size={14} className="mr-2" /> Chat
                </TabsTrigger>
                <TabsTrigger
                  value="suggestions"
                  className="data-[state=active]:bg-[#2d3748] data-[state=active]:text-[#f7fafc]"
                >
                  <Lightbulb size={14} className="mr-2" /> Suggestions
                </TabsTrigger>
                <TabsTrigger
                  value="history"
                  className="data-[state=active]:bg-[#2d3748] data-[state=active]:text-[#f7fafc]"
                >
                  <History size={14} className="mr-2" /> History
                </TabsTrigger>
              </TabsList>

              <TabsContent value="chat" className="flex-1 flex flex-col p-0 m-0">
                <ScrollArea className="flex-1 p-3">
                  {chatHistory.map((msg, index) => (
                    <div
                      key={index}
                      className={`mb-3 ${msg.role === "assistant" ? "bg-[#1a202c]" : "bg-[#2d3748]"} p-2 rounded-lg`}
                    >
                      <div className="flex items-start gap-2">
                        <div className={`mt-1 ${msg.role === "assistant" ? "text-[#3b82f6]" : "text-[#f56565]"}`}>
                          {msg.role === "assistant" ? <Bot size={16} /> : <User size={16} />}
                        </div>
                        <div className="flex-1">
                          <p className="text-[#f7fafc] whitespace-pre-wrap">{msg.content}</p>
                          {msg.role === "assistant" && (
                            <div className="flex justify-end mt-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 text-[#a0aec0] hover:text-[#3b82f6]"
                                title="Like this response"
                              >
                                <ThumbsUp size={12} />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {isProcessing && (
                    <div className="flex items-center gap-2 text-[#a0aec0]">
                      <div className="animate-pulse">
                        <Bot size={16} className="text-[#3b82f6]" />
                      </div>
                      <span>Thinking...</span>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </ScrollArea>

                <form onSubmit={handleChatSubmit} className="p-2 border-t border-[#2d3748] flex">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    className="flex-1 bg-[#1a202c] border border-[#2d3748] rounded-l-md px-3 py-2 outline-none text-[#f7fafc]"
                    placeholder="Ask me anything..."
                    disabled={isProcessing}
                  />
                  <Button
                    type="submit"
                    className="bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded-r-md px-3 py-2"
                    disabled={isProcessing}
                  >
                    <Send size={16} />
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="suggestions" className="flex-1 p-0 m-0">
                <ScrollArea className="h-full p-3">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-[#a0aec0]">Command Suggestions</h3>
                    {suggestions.length > 0 ? (
                      suggestions.map((suggestion, index) => (
                        <div
                          key={index}
                          className="bg-[#1a202c] p-2 rounded-md hover:bg-[#2d3748] cursor-pointer"
                          onClick={() => handleSuggestionClick(suggestion)}
                        >
                          <p className="text-[#f7fafc]">{suggestion}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-[#a0aec0]">Type in the terminal to see suggestions</p>
                    )}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="history" className="flex-1 p-0 m-0">
                <ScrollArea className="h-full p-3">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-[#a0aec0]">Command History</h3>
                    {commandHistory.length > 0 ? (
                      commandHistory.map((cmd, index) => (
                        <div
                          key={index}
                          className="bg-[#1a202c] p-2 rounded-md hover:bg-[#2d3748] cursor-pointer flex justify-between items-center"
                        >
                          <p className="text-[#f7fafc]">{cmd}</p>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 text-[#a0aec0] hover:text-[#3b82f6]"
                              onClick={() => handleHistoryClick(cmd)}
                              title="Use this command"
                            >
                              <Command size={12} />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 text-[#a0aec0] hover:text-[#48bb78]"
                              onClick={() => handleRunCommand(cmd)}
                              title="Run this command"
                            >
                              <Send size={12} />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-[#a0aec0]">No command history yet</p>
                    )}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          )}

          {/* Resize handles */}
          <div
            className="absolute bottom-0 right-0 w-6 h-6 cursor-se-resize flex items-center justify-center text-[#2d3748] hover:text-[#3b82f6]"
            onMouseDown={(e) => handleMouseDown(e, "resize", "se")}
            onTouchStart={(e) => handleTouchStart(e, "resize", "se")}
          >
            <CornerRightDown size={14} />
          </div>
          <div
            className="absolute bottom-0 left-0 right-6 h-2 cursor-s-resize"
            onMouseDown={(e) => handleMouseDown(e, "resize", "s")}
            onTouchStart={(e) => handleTouchStart(e, "resize", "s")}
          />
          <div
            className="absolute top-0 bottom-6 right-0 w-2 cursor-e-resize"
            onMouseDown={(e) => handleMouseDown(e, "resize", "e")}
            onTouchStart={(e) => handleTouchStart(e, "resize", "e")}
          />
        </div>
      )}
    </TooltipProvider>
  )
}

