"use client"

import { useState } from "react"
import { Activity, BarChart3, Clock, Database, FileText, Lock, Shield, Terminal, Zap } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { tools } from "@/lib/tools-data"
import { Button } from "@/components/ui/button"

export function DashboardView() {
  const [recentActivities] = useState([
    {
      id: 1,
      action: "Nmap scan completed",
      target: "192.168.1.100",
      timestamp: "10 minutes ago",
      status: "success",
    },
    {
      id: 2,
      action: "Gobuster directory scan",
      target: "example.com",
      timestamp: "25 minutes ago",
      status: "success",
    },
    {
      id: 3,
      action: "Hydra brute force attempt",
      target: "10.0.0.15",
      timestamp: "1 hour ago",
      status: "failed",
    },
    {
      id: 4,
      action: "TheHarvester email collection",
      target: "targetcompany.com",
      timestamp: "2 hours ago",
      status: "success",
    },
    {
      id: 5,
      action: "Metasploit exploitation",
      target: "192.168.1.50",
      timestamp: "3 hours ago",
      status: "in-progress",
    },
  ])

  // Calculate tool statistics by category
  const toolStats = tools.reduce(
    (acc, tool) => {
      if (!acc[tool.category]) {
        acc[tool.category] = 0
      }
      acc[tool.category]++
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tools</CardTitle>
            <Database className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tools.length}</div>
            <p className="text-xs text-gray-400">Across {Object.keys(toolStats).length} categories</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Security Tools</CardTitle>
            <Shield className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toolStats["cybersecurity"] || 0}</div>
            <p className="text-xs text-gray-400">Cybersecurity & Threat Intelligence</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Data Analysis</CardTitle>
            <BarChart3 className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toolStats["web-scraping"] || 0}</div>
            <p className="text-xs text-gray-400">Web Scraping & Data Analysis</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">API Tools</CardTitle>
            <Zap className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toolStats["apis"] || 0}</div>
            <p className="text-xs text-gray-400">APIs & Data Sources</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="md:col-span-2 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
            <CardDescription className="text-gray-400">Your latest tool executions and scans</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center">
                  <div className="mr-4">
                    <div
                      className={`p-2 rounded-full ${
                        activity.status === "success"
                          ? "bg-green-900 text-green-300"
                          : activity.status === "failed"
                            ? "bg-red-900 text-red-300"
                            : "bg-yellow-900 text-yellow-300"
                      }`}
                    >
                      {activity.status === "success" ? (
                        <Shield className="h-4 w-4" />
                      ) : activity.status === "failed" ? (
                        <Lock className="h-4 w-4" />
                      ) : (
                        <Clock className="h-4 w-4" />
                      )}
                    </div>
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{activity.action}</p>
                    <p className="text-sm text-gray-400">Target: {activity.target}</p>
                  </div>
                  <div className="text-xs text-gray-400">{activity.timestamp}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription className="text-gray-400">Frequently used tools and commands</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Button
                className="w-full flex items-center space-x-2 bg-blue-900 hover:bg-blue-800"
                onClick={() => {
                  const event = new CustomEvent("run-command", {
                    detail: "help",
                  })
                  document.dispatchEvent(event)
                }}
              >
                <Terminal className="h-4 w-4" />
                <span>Open Terminal</span>
              </Button>
              <Button
                className="w-full flex items-center space-x-2 bg-blue-900 hover:bg-blue-800"
                onClick={() => {
                  const event = new CustomEvent("run-command", {
                    detail: "nmap -sV 192.168.1.1",
                  })
                  document.dispatchEvent(event)
                }}
              >
                <Activity className="h-4 w-4" />
                <span>Network Scan</span>
              </Button>
              <Button className="w-full flex items-center space-x-2 bg-blue-900 hover:bg-blue-800">
                <FileText className="h-4 w-4" />
                <span>Generate Report</span>
              </Button>
              <Button
                className="w-full flex items-center space-x-2 bg-blue-900 hover:bg-blue-800"
                onClick={() => {
                  const event = new CustomEvent("run-command", {
                    detail: "nikto -h example.com",
                  })
                  document.dispatchEvent(event)
                }}
              >
                <Shield className="h-4 w-4" />
                <span>Vulnerability Scan</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

