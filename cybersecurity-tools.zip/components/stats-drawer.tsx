"use client"

import { X, Database, Activity, Clock, EyeOff, Download, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { tools } from "@/lib/tools-data"
import { useState } from "react"

interface StatsDrawerProps {
  isOpen: boolean
  onClose: () => void
}

export function StatsDrawer({ isOpen, onClose }: StatsDrawerProps) {
  const [recentActivities] = useState([
    {
      id: 1,
      action: "Metasploit exploitation",
      target: "192.168.1.50",
      timestamp: "3 hours ago",
      status: "in-progress",
    },
    {
      id: 2,
      action: "Nmap scan completed",
      target: "192.168.1.100",
      timestamp: "10 minutes ago",
      status: "success",
    },
  ])

  // Calculate tool statistics by category
  const toolStats = tools.reduce(
    (acc, tool) => {
      if (!acc[tool.category]) {
        acc[tool.category] = 0
      }
      acc[tool.category]++
      return acc
    },
    {} as Record<string, number>,
  )

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-end transition-all duration-300">
      <div className="w-full max-w-md bg-[#0a0e17] border-l border-[#1e2738] flex flex-col h-full shadow-xl">
        <div className="flex items-center justify-between p-4 border-b border-[#1e2738]">
          <h2 className="text-lg font-bold bg-gradient-to-r from-[#5d7ce9] to-[#8a63d2] bg-clip-text text-transparent flex items-center gap-2">
            <EyeOff className="h-5 w-5 text-[#5d7ce9]" />
            CloakAI0 Analytics
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-[#1e2738] hover:text-[#5d7ce9]">
            <X size={18} />
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-6">
          {/* Tool Stats */}
          <div>
            <h3 className="text-lg font-bold mb-3 flex items-center gap-2 text-[#d4d8e3]">
              <Database size={18} className="text-[#5d7ce9]" />
              Tool Statistics
            </h3>
            <div className="grid grid-cols-4 gap-4 text-center">
              <div className="bg-[#151c2c] p-3 rounded-lg border border-[#1e2738] shadow-md">
                <p className="text-xs text-[#8a92a9]">Total</p>
                <p className="text-2xl font-bold text-[#d4d8e3]">{tools.length}</p>
              </div>
              <div className="bg-[#151c2c] p-3 rounded-lg border border-[#1e2738] shadow-md">
                <p className="text-xs text-[#8a92a9]">Security</p>
                <p className="text-2xl font-bold text-[#d4d8e3]">{toolStats["cybersecurity"] || 0}</p>
              </div>
              <div className="bg-[#151c2c] p-3 rounded-lg border border-[#1e2738] shadow-md">
                <p className="text-xs text-[#8a92a9]">Data</p>
                <p className="text-2xl font-bold text-[#d4d8e3]">{toolStats["web-scraping"] || 0}</p>
              </div>
              <div className="bg-[#151c2c] p-3 rounded-lg border border-[#1e2738] shadow-md">
                <p className="text-xs text-[#8a92a9]">APIs</p>
                <p className="text-2xl font-bold text-[#d4d8e3]">{toolStats["apis"] || 0}</p>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div>
            <h3 className="text-lg font-bold mb-3 flex items-center gap-2 text-[#d4d8e3]">
              <Activity size={18} className="text-[#5d7ce9]" />
              Recent Activity
            </h3>
            <div className="space-y-3">
              {recentActivities.map((activity) => (
                <div
                  key={activity.id}
                  className="bg-[#151c2c] p-3 rounded-lg border border-[#1e2738] shadow-md flex items-center"
                >
                  <div className="mr-3">
                    <div
                      className={`p-2 rounded-full ${
                        activity.status === "success"
                          ? "bg-[#193a3a] text-[#4ade80]"
                          : activity.status === "failed"
                            ? "bg-[#3a1919] text-[#f87171]"
                            : "bg-[#3a3919] text-[#facc15]"
                      }`}
                    >
                      <Clock className="h-4 w-4" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-[#d4d8e3]">{activity.action}</p>
                    <p className="text-sm text-[#8a92a9]">Target: {activity.target}</p>
                  </div>
                  <div className="text-xs text-[#8a92a9]">{activity.timestamp}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Saved Sessions */}
          <div>
            <h3 className="text-lg font-bold mb-3 flex items-center gap-2 text-[#d4d8e3]">
              <Save size={18} className="text-[#5d7ce9]" />
              Saved Sessions
            </h3>
            <div className="bg-[#151c2c] p-3 rounded-lg border border-[#1e2738] shadow-md">
              <p className="text-sm text-[#8a92a9] mb-2">
                Sessions are automatically saved for 7 days. Export to keep them longer.
              </p>
              <div className="space-y-2">
                <div className="flex justify-between items-center p-2 bg-[#0a0e17] rounded border border-[#1e2738]">
                  <span className="text-[#d4d8e3]">Recon-192.168.1.1</span>
                  <span className="text-xs text-[#8a92a9]">2 hours ago</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-[#0a0e17] rounded border border-[#1e2738]">
                  <span className="text-[#d4d8e3]">Pentest-example.com</span>
                  <span className="text-xs text-[#8a92a9]">Yesterday</span>
                </div>
              </div>
              <div className="mt-3 flex gap-2">
                <Button className="flex-1 text-xs bg-[#2a3552] hover:bg-[#344066] text-[#d4d8e3]" variant="default">
                  <Download size={12} className="mr-1" /> Export All
                </Button>
                <Button className="flex-1 text-xs bg-[#2a3552] hover:bg-[#344066] text-[#d4d8e3]" variant="default">
                  Import
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

