"use client"
import { BarChart2, Terminal, Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMobile } from "@/hooks/use-mobile"
import { ThemeToggle } from "@/components/theme-toggle"
import { OSSwitcher } from "@/components/os-switcher"

interface MainNavProps {
  activeView: string
  onViewChange: (view: string) => void
  onToggleStats: () => void
  onSwitchOS?: (os: string) => void
}

export function MainNav({ activeView, onViewChange, onToggleStats, onSwitchOS }: MainNavProps) {
  const { isMobile } = useMobile()

  const handleViewChange = (view: string) => {
    onViewChange(view)
  }

  const handleSwitchOS = (os: string) => {
    if (onSwitchOS) {
      onSwitchOS(os)
    }
  }

  return (
    <div className="bg-[#0a0e17] border-b border-[#1e2738] shadow-lg">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="relative">
              <EyeOff
                className="h-6 w-6 text-[#5d7ce9] absolute opacity-70 animate-pulse"
                style={{ animationDuration: "3s" }}
              />
              <Eye className="h-6 w-6 text-[#5d7ce9]" />
            </div>
            <span className="font-bold text-lg bg-gradient-to-r from-[#5d7ce9] to-[#8a63d2] bg-clip-text text-transparent">
              CloakAI0
            </span>
          </div>

          {/* OS Switcher */}
          {!isMobile && (
            <div className="flex-1 flex justify-center">
              <OSSwitcher onSwitchOS={handleSwitchOS} />
            </div>
          )}

          {/* Desktop navigation */}
          <nav className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className={`flex items-center space-x-1 ${
                activeView === "terminal"
                  ? "text-[#5d7ce9] icon-glow"
                  : "text-gray-400 hover:text-[#5d7ce9] hover:icon-glow"
              }`}
              onClick={() => handleViewChange("terminal")}
            >
              <Terminal className="h-5 w-5" />
              <span className={isMobile ? "sr-only" : ""}>Terminal</span>
            </Button>

            {/* Stats button */}
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-1 text-gray-400 hover:text-[#5d7ce9] hover:icon-glow"
              onClick={onToggleStats}
            >
              <BarChart2 className="h-5 w-5" />
              <span className={isMobile ? "sr-only" : ""}>Analytics</span>
            </Button>

            {/* Mobile OS Switcher */}
            {isMobile && <OSSwitcher onSwitchOS={handleSwitchOS} />}

            <ThemeToggle />
          </nav>
        </div>
      </div>
    </div>
  )
}

