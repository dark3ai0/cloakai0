"use client"

import { Activity, FileText, Terminal } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { tools } from "@/lib/tools-data"

interface QuickActionsPanelProps {
  onOpenTerminal: () => void
}

export function QuickActionsPanel({ onOpenTerminal }: QuickActionsPanelProps) {
  // Calculate tool statistics by category
  const toolStats = tools.reduce(
    (acc, tool) => {
      if (!acc[tool.category]) {
        acc[tool.category] = 0
      }
      acc[tool.category]++
      return acc
    },
    {} as Record<string, number>,
  )

  const recentActivities = [
    {
      id: 1,
      action: "Metasploit exploitation",
      target: "192.168.1.50",
      timestamp: "3 hours ago",
      status: "in-progress",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {/* Stats Card */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-xl font-bold">Total Tools</h3>
              <p className="text-4xl font-bold mt-2">{tools.length}</p>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-sm text-gray-400">Security</p>
                <p className="text-lg font-semibold">{toolStats["cybersecurity"] || 0}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Data</p>
                <p className="text-lg font-semibold">{toolStats["web-scraping"] || 0}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">APIs</p>
                <p className="text-lg font-semibold">{toolStats["apis"] || 0}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity Card */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-lg font-bold mb-2">Recent Activity</h3>
          {recentActivities.map((activity) => (
            <div key={activity.id} className="flex items-center">
              <div className="mr-4">
                <div
                  className={`p-2 rounded-full ${
                    activity.status === "success"
                      ? "bg-green-900 text-green-300"
                      : activity.status === "failed"
                        ? "bg-red-900 text-red-300"
                        : "bg-yellow-900 text-yellow-300"
                  }`}
                >
                  <Activity className="h-4 w-4" />
                </div>
              </div>
              <div className="flex-1">
                <p className="font-medium">{activity.action}</p>
                <p className="text-sm text-gray-400">Target: {activity.target}</p>
              </div>
              <div className="text-xs text-gray-400">{activity.timestamp}</div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quick Actions Card */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-lg font-bold mb-2">Quick Actions</h3>
          <div className="space-y-2">
            <Button
              className="w-full flex items-center justify-start gap-2 bg-blue-900 hover:bg-blue-800"
              onClick={onOpenTerminal}
            >
              <Terminal className="h-4 w-4" />
              <span>Open Terminal</span>
            </Button>
            <Button
              className="w-full flex items-center justify-start gap-2 bg-blue-900 hover:bg-blue-800"
              onClick={() => {
                const event = new CustomEvent("run-command", {
                  detail: "nmap -sV 192.168.1.1",
                })
                document.dispatchEvent(event)
              }}
            >
              <Activity className="h-4 w-4" />
              <span>Network Scan</span>
            </Button>
            <Button className="w-full flex items-center justify-start gap-2 bg-blue-900 hover:bg-blue-800">
              <FileText className="h-4 w-4" />
              <span>Generate Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

