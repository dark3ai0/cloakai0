"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import {
  Terminal,
  X,
  Smartphone,
  Monitor,
  User,
  AtSign,
  Phone,
  Globe,
  HardDrive,
  EyeOff,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { TerminalAIAssistant } from "@/components/terminal-ai-assistant"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useMobile } from "@/hooks/use-mobile"
import { TerminalEngine } from "@/lib/terminal-engine"
import { TargetManager, type Target } from "@/lib/target-manager"
import { Input } from "@/components/ui/input"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import type { LinuxDistro } from "@/lib/terminal-engine"

// Update the TerminalSandbox component props and styling
interface TerminalSandboxProps {
  isOpen: boolean
  onClose: () => void
  isMainView?: boolean
  apiKey?: string
  initialOS?: string
}

export function TerminalSandbox({
  isOpen,
  onClose,
  isMainView = false,
  apiKey,
  initialOS = "kali",
}: TerminalSandboxProps) {
  const [input, setInput] = useState("")
  const [history, setHistory] = useState<Array<{ type: "input" | "output"; content: string }>>([])
  const [isMaximized, setIsMaximized] = useState(true) // Default to maximized
  const [isMobileView, setIsMobileView] = useState(false)
  const { isMobile } = useMobile()
  const targetManager = useRef(new TargetManager()).current
  const [terminalEngine] = useState(() => new TerminalEngine(targetManager, apiKey))
  const [target, setTarget] = useState<Target>(targetManager.getTarget())
  const [activeTab, setActiveTab] = useState<string>("terminal")
  const [isTargetOpen, setIsTargetOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const inputRef = useRef<HTMLInputElement>(null)
  const historyEndRef = useRef<HTMLDivElement>(null)
  const terminalRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen])

  useEffect(() => {
    historyEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [history])

  // Set initial mobile view based on device
  useEffect(() => {
    setIsMobileView(isMobile)
  }, [isMobile])

  // Initialize terminal engine and listen for target updates
  useEffect(() => {
    // Initialize with the specified OS
    if (initialOS && terminalEngine) {
      terminalEngine.setDistro(initialOS as LinuxDistro)
    }

    // Listen for OS switch events
    const handleSwitchOS = (event: CustomEvent) => {
      const { os } = event.detail
      if (os && terminalEngine) {
        terminalEngine.switchOS(os)
      }
    }

    document.addEventListener("switch-os" as any, handleSwitchOS as EventListener)

    return () => {
      document.removeEventListener("switch-os" as any, handleSwitchOS as EventListener)
    }
  }, [terminalEngine, initialOS])

  useEffect(() => {
    // Set welcome message
    const welcomeMessage =
      "Welcome to CloakAI Terminal\n# Type a command or use the target panel to set information\n# Type 'help' for available commands"
    setHistory([{ type: "output", content: welcomeMessage }])

    // Auto-install Ollama and run Gemma model on startup
    const initializeAI = async () => {
      setHistory((prev) => [...prev, { type: "output", content: "Initializing AI assistant..." }])

      // Execute the command to install Ollama
      executeCommand("curl -fsSL https://ollama.com/install.sh | sh")

      // Wait a bit before running the model
      setTimeout(() => {
        executeCommand("ollama run gemma:2b")
      }, 3000)
    }

    initializeAI()

    terminalEngine.onOutput((output) => {
      setHistory((prev) => [...prev, { type: "output", content: output }])
    })

    // Listen for custom events from the AI assistant
    const handleRunCommand = (event: CustomEvent) => {
      const command = event.detail
      if (command) {
        executeCommand(command)
      }
    }

    // Listen for target updates
    targetManager.addListener((newTarget) => {
      setTarget({ ...newTarget })
    })

    document.addEventListener("run-command" as any, handleRunCommand as EventListener)

    return () => {
      document.removeEventListener("run-command" as any, handleRunCommand as EventListener)
    }
  }, [terminalEngine, targetManager])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    executeCommand(input)
  }

  const executeCommand = useCallback(
    async (cmd: string) => {
      // Add the command to history
      setHistory((prev) => [...prev, { type: "input", content: cmd }])
      setIsLoading(true)

      try {
        // Process the command through the terminal engine
        await terminalEngine.execute(cmd)
      } catch (error) {
        setHistory((prev) => [...prev, { type: "output", content: `Error: ${error}` }])
      } finally {
        setIsLoading(false)
      }

      // Clear the input
      setInput("")
    },
    [terminalEngine],
  )

  const handleSuggestCommand = (command: string) => {
    setInput(command)
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }

  const handleExecuteCommand = (command: string) => {
    executeCommand(command)
  }

  const toggleMobileView = () => {
    setIsMobileView(!isMobileView)
  }

  const handleTargetUpdate = (field: keyof Target, value: string) => {
    targetManager.updateField(field, value)
  }

  const getPromptPrefix = (): string => {
    return terminalEngine.getDistro() === "kali" ? "# " : "# "
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowUp") {
      e.preventDefault()
      const prevCmd = terminalEngine.getPreviousCommand()
      if (prevCmd) setInput(prevCmd)
    } else if (e.key === "ArrowDown") {
      e.preventDefault()
      const nextCmd = terminalEngine.getNextCommand()
      setInput(nextCmd)
    } else if (e.key === "Tab") {
      e.preventDefault()
      // Simple tab completion for commands
      if (input.trim()) {
        const possibleCommands = [
          "help",
          "clear",
          "ls",
          "cd",
          "cat",
          "nmap",
          "dirb",
          "gobuster",
          "sqlmap",
          "nikto",
          "wpscan",
          "hydra",
          "crackmapexec",
          "metasploit",
          "aircrack-ng",
          "set-target",
          "show-target",
          "change-distro",
          "whois",
          "theHarvester",
        ]

        const matchingCommands = possibleCommands.filter((cmd) => cmd.startsWith(input.split(" ")[0].toLowerCase()))

        if (matchingCommands.length === 1) {
          // If there's only one match, complete it
          setInput(input.replace(/^\S+/, matchingCommands[0]))
        } else if (matchingCommands.length > 1) {
          // If there are multiple matches, show them
          setHistory((prev) => [
            ...prev,
            { type: "input", content: input },
            { type: "output", content: matchingCommands.join("  ") },
          ])
        }
      }
    }
  }

  if (!isOpen) return null

  return (
    <div className="w-full max-w-6xl mx-auto bg-[#0f1117] text-[#e2e8f0] font-mono text-sm border border-[#2d3748] rounded-xl shadow-2xl overflow-hidden flex flex-col">
      {/* Update the terminal header to show the current OS with an icon */}
      <div className="flex items-center justify-between p-2 bg-[#1a202c] border-b border-[#2d3748]">
        <div className="flex items-center gap-2">
          <Terminal size={16} className="text-[#3b82f6]" />
          <span className="text-[#f7fafc] font-medium">
            {terminalEngine.getDistro() === "kali" ? (
              <>
                CloakAI Terminal - <span className="text-[#f56565]">Kali Linux</span>
              </>
            ) : terminalEngine.getDistro() === "alpine" ? (
              <>
                CloakAI Terminal - <span className="text-[#3b82f6]">Alpine Linux</span>
              </>
            ) : (
              <>CloakAI Terminal</>
            )}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Label htmlFor="mobile-toggle" className="text-xs text-[#a0aec0]">
              {isMobileView ? <Smartphone size={14} /> : <Monitor size={14} />}
            </Label>
            <Switch id="mobile-toggle" checked={isMobileView} onCheckedChange={toggleMobileView} />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-[#a0aec0] hover:text-[#f56565] hover:bg-[#3a1919]"
            onClick={onClose}
          >
            <X size={14} />
          </Button>
        </div>
      </div>

      <div className="flex flex-col flex-1 h-full">
        {/* Main Terminal Area */}
        <div ref={terminalRef} className="flex-1 overflow-hidden flex flex-col">
          {/* Command Palette */}
          <div className="p-2 border-b border-[#2d3748] bg-[#1a202c] flex flex-wrap gap-1">
            <Button
              variant="outline"
              size="sm"
              className="h-6 text-xs bg-[#0f1117] border-[#2d3748] hover:bg-[#2d3748] hover:text-[#3b82f6]"
              onClick={() => executeCommand("clear")}
            >
              Clear
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-6 text-xs bg-[#0f1117] border-[#2d3748] hover:bg-[#2d3748] hover:text-[#3b82f6]"
              onClick={() => executeCommand("show-target")}
            >
              Show Target
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-6 text-xs bg-[#0f1117] border-[#2d3748] hover:bg-[#2d3748] hover:text-[#3b82f6]"
              onClick={() => executeCommand(`nmap -sV ${target.ip || target.domain || "<target>"}`)}
              disabled={!target.ip && !target.domain}
            >
              Scan Target
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-6 text-xs bg-[#0f1117] border-[#2d3748] hover:bg-[#2d3748] hover:text-[#3b82f6]"
              onClick={() => setIsTargetOpen(!isTargetOpen)}
            >
              {isTargetOpen ? "Hide Target" : "Show Target"}
            </Button>
          </div>

          {/* Terminal Output */}
          <ScrollArea className="flex-1 p-3 bg-[#0f1117]">
            {history.map((entry, index) => (
              <div key={index} className="mb-1">
                {entry.type === "input" ? (
                  <div className="flex whitespace-pre-wrap">
                    <span className="text-[#f56565] mr-1 whitespace-pre-wrap">{getPromptPrefix()}</span>
                    <span className="text-[#f7fafc]">{entry.content}</span>
                  </div>
                ) : (
                  <div className="whitespace-pre-wrap text-[#48bb78]">{entry.content}</div>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex items-center text-[#a0aec0]">
                <span className="animate-pulse">Processing...</span>
              </div>
            )}
            <div ref={historyEndRef} />
          </ScrollArea>

          {/* Terminal Input */}
          <form onSubmit={handleSubmit} className="p-2 border-t border-[#2d3748] flex bg-[#1a202c]">
            <span className="text-[#f56565] mr-1">{getPromptPrefix()}</span>
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1 bg-transparent outline-none text-[#48bb78]"
              placeholder="Type a command..."
              autoFocus
            />
          </form>
        </div>

        {/* Collapsible Target info panel */}
        <Collapsible open={isTargetOpen} onOpenChange={setIsTargetOpen} className="border-t border-[#2d3748]">
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between p-2 bg-[#1a202c] cursor-pointer hover:bg-[#2d3748] transition-colors">
              <div className="flex items-center gap-2">
                <EyeOff size={14} className="text-[#3b82f6]" />
                <span className="text-sm font-medium text-[#f7fafc]">Target Information</span>
              </div>
              {isTargetOpen ? (
                <ChevronUp size={14} className="text-[#a0aec0]" />
              ) : (
                <ChevronDown size={14} className="text-[#a0aec0]" />
              )}
            </div>
          </CollapsibleTrigger>
          <CollapsibleContent className="bg-[#1a202c] p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div className="flex flex-col space-y-2">
                <Label htmlFor="target-ip" className="text-[#a0aec0] flex items-center gap-1">
                  <HardDrive size={12} /> IP Address
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="target-ip"
                    value={target.ip}
                    onChange={(e) => handleTargetUpdate("ip", e.target.value)}
                    placeholder="192.168.1.1"
                    className="bg-[#0f1117] border-[#2d3748] text-[#f7fafc]"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc] border-[#2d3748]"
                    onClick={() => executeCommand(`set-target ip ${target.ip}`)}
                  >
                    Set
                  </Button>
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                <Label htmlFor="target-domain" className="text-[#a0aec0] flex items-center gap-1">
                  <Globe size={12} /> Domain
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="target-domain"
                    value={target.domain}
                    onChange={(e) => handleTargetUpdate("domain", e.target.value)}
                    placeholder="example.com"
                    className="bg-[#0f1117] border-[#2d3748] text-[#f7fafc]"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc] border-[#2d3748]"
                    onClick={() => executeCommand(`set-target domain ${target.domain}`)}
                  >
                    Set
                  </Button>
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                <Label htmlFor="target-username" className="text-[#a0aec0] flex items-center gap-1">
                  <User size={12} /> Username
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="target-username"
                    value={target.username}
                    onChange={(e) => handleTargetUpdate("username", e.target.value)}
                    placeholder="johndoe"
                    className="bg-[#0f1117] border-[#2d3748] text-[#f7fafc]"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc] border-[#2d3748]"
                    onClick={() => executeCommand(`set-target username ${target.username}`)}
                  >
                    Set
                  </Button>
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                <Label htmlFor="target-email" className="text-[#a0aec0] flex items-center gap-1">
                  <AtSign size={12} /> Email
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="target-email"
                    value={target.email}
                    onChange={(e) => handleTargetUpdate("email", e.target.value)}
                    placeholder="john@example.com"
                    className="bg-[#0f1117] border-[#2d3748] text-[#f7fafc]"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc] border-[#2d3748]"
                    onClick={() => executeCommand(`set-target email ${target.email}`)}
                  >
                    Set
                  </Button>
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                <Label htmlFor="target-phone" className="text-[#a0aec0] flex items-center gap-1">
                  <Phone size={12} /> Phone
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="target-phone"
                    value={target.phoneNumber}
                    onChange={(e) => handleTargetUpdate("phoneNumber", e.target.value)}
                    placeholder="+1234567890"
                    className="bg-[#0f1117] border-[#2d3748] text-[#f7fafc]"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc] border-[#2d3748]"
                    onClick={() => executeCommand(`set-target phone ${target.phoneNumber}`)}
                  >
                    Set
                  </Button>
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                <Label className="text-[#a0aec0]">System</Label>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={terminalEngine.getDistro() === "kali" ? "default" : "outline"}
                    className={`flex-1 text-xs ${terminalEngine.getDistro() === "kali" ? "bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc]" : "bg-[#0f1117] border-[#2d3748] hover:bg-[#2d3748] hover:text-[#3b82f6]"}`}
                    onClick={() => executeCommand("change-distro kali")}
                  >
                    Kali Linux
                  </Button>
                  <Button
                    size="sm"
                    variant={terminalEngine.getDistro() === "alpine" ? "default" : "outline"}
                    className={`flex-1 text-xs ${terminalEngine.getDistro() === "alpine" ? "bg-[#2d3748] hover:bg-[#3b4a69] text-[#f7fafc]" : "bg-[#0f1117] border-[#2d3748] hover:bg-[#2d3748] hover:text-[#3b82f6]"}`}
                    onClick={() => executeCommand("change-distro alpine")}
                  >
                    Alpine Linux
                  </Button>
                </div>
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </div>

      {/* AI Assistant */}
      <TerminalAIAssistant
        input={input}
        history={history}
        onSuggestCommand={handleSuggestCommand}
        onExecuteCommand={handleExecuteCommand}
        terminalEngine={terminalEngine}
      />
    </div>
  )
}

